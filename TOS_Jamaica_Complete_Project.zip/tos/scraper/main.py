"""
TOS Transit Scraper — Main Entry Point
═══════════════════════════════════════════════════════════════
Runs as a standalone service inside Docker.
Starts both:
  1. The FastAPI REST API (for the backend to call)
  2. The weekly scheduler (every Sunday 2AM Jamaica time)

Connects to the same PostgreSQL database as the backend.
"""

import asyncio
import logging
import os
import json
from pathlib import Path
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI

# Add parent to path so imports work
import sys
sys.path.insert(0, str(Path(__file__).parent))

from api.transit_router   import router as transit_router
from scheduler.orchestrator import start_scheduler, run_all_scrapers
from storage.database       import TransitDatabase

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt = "%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("tos_scraper")

# ─── Shared DB instance ───────────────────────────────────────────────────────
_db: TransitDatabase | None = None

async def get_shared_db() -> TransitDatabase:
    global _db
    if _db is None:
        _db = TransitDatabase()
        await _db.init()
    return _db

# ─── App lifecycle ────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: init DB, run initial scrape if needed, start scheduler."""
    logger.info("🚀 TOS Scraper Service starting...")

    db = await get_shared_db()

    # Run initial scrape on first boot if no data yet
    hashes = await db.get_content_hashes()
    if not hashes:
        logger.info("No previous scrape data found — running initial scrape now...")
        report = await run_all_scrapers(db)
        logger.info(f"Initial scrape complete: {report}")

    # Start weekly scheduler
    start_scheduler()
    logger.info("✅ Scraper service ready — weekly schedule active (Sunday 2AM Jamaica)")

    # Watch for manual trigger file from backend
    asyncio.create_task(watch_trigger_file(db))

    yield

    logger.info("Scraper service shutting down...")

async def watch_trigger_file(db: TransitDatabase):
    """
    Watches for /app/data/scrape_trigger.json written by the backend
    when admin triggers a manual scrape via POST /api/transit/scrape.
    """
    trigger_path = Path("/app/data/scrape_trigger.json")
    processed_path = Path("/app/data/scrape_trigger.processed.json")

    while True:
        await asyncio.sleep(30)  # check every 30 seconds
        try:
            if trigger_path.exists():
                data = json.loads(trigger_path.read_text())
                triggered_at = data.get("triggered_at")
                source       = data.get("source", "all")

                # Avoid reprocessing the same trigger
                if processed_path.exists():
                    prev = json.loads(processed_path.read_text())
                    if prev.get("triggered_at") == triggered_at:
                        continue

                logger.info(f"Manual scrape triggered for: {source}")

                if source != "all":
                    from scheduler.orchestrator import SCRAPERS
                    filtered = [c for c in SCRAPERS if c.__new__(c).source_name == source]
                    if filtered:
                        import scheduler.orchestrator as orch
                        original   = orch.SCRAPERS
                        orch.SCRAPERS = filtered
                        await run_all_scrapers(db)
                        orch.SCRAPERS = original
                else:
                    await run_all_scrapers(db)

                # Mark as processed
                trigger_path.rename(processed_path)
                logger.info("Manual scrape complete")

        except Exception as e:
            logger.error(f"Error in trigger watcher: {e}")

# ─── FastAPI app ──────────────────────────────────────────────────────────────

app = FastAPI(
    title       = "TOS Transit Scraper",
    description = "Jamaica Transit Data Scraper — weekly data collection service",
    version     = "1.0.0",
    lifespan    = lifespan,
)

app.include_router(transit_router, prefix="/transit", tags=["Transit Data"])

@app.get("/health")
async def health():
    return {
        "status":  "ok",
        "service": "TOS Scraper",
        "version": "1.0.0",
    }

# ─── Entry point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host    = "0.0.0.0",
        port    = int(os.getenv("SCRAPER_PORT", "8001")),
        reload  = False,
        workers = 1,
    )
