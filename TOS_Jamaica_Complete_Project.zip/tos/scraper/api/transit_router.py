"""
Transit Data API
──────────────────────────────────────────────────────────────────────────────
Exposes scraped transit data via REST endpoints.
This plugs directly into your existing StudentOS/TransitApp backend.

Endpoints:
  GET /transit/fares          — All fares (filterable by operator/route)
  GET /transit/routes         — All routes
  GET /transit/stops          — All stops/terminals
  GET /transit/schedules      — Intercity schedules
  GET /transit/status         — Last scrape run summary
  POST /transit/scrape        — Trigger a manual scrape (admin only)
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from typing import Optional
import json
from pathlib import Path

from storage.database import TransitDatabase
from scheduler.orchestrator import run_all_scrapers, SCRAPERS

router = APIRouter()

# Shared DB instance (in production, inject via dependency)
_db: Optional[TransitDatabase] = None

async def get_db() -> TransitDatabase:
    global _db
    if _db is None:
        _db = TransitDatabase()
        await _db.init()
    return _db


# ─── Fares ────────────────────────────────────────────────────────────────────

@router.get("/fares")
async def get_fares(
    operator:    Optional[str] = Query(None, description="Filter by operator e.g. 'JUTC', 'Route Taxi', 'Knutsford'"),
    origin:      Optional[str] = Query(None, description="Origin stop/city"),
    destination: Optional[str] = Query(None, description="Destination stop/city"),
    db: TransitDatabase = Depends(get_db),
):
    """
    Returns all current transit fares.
    Fares are updated weekly from JUTC, OUR (route taxi regulations), and Knutsford Express.
    """
    fares = await db.get_fares(operator=operator, origin=origin, destination=destination)
    return {
        "count":  len(fares),
        "fares":  fares,
    }


# ─── Routes ───────────────────────────────────────────────────────────────────

@router.get("/routes")
async def get_routes(
    operator: Optional[str] = Query(None),
    db: TransitDatabase = Depends(get_db),
):
    """Returns all active bus and taxi routes."""
    routes = await db.get_routes(operator=operator)
    return {"count": len(routes), "routes": routes}


# ─── Stops ────────────────────────────────────────────────────────────────────

@router.get("/stops")
async def get_stops(
    parish:   Optional[str] = Query(None, description="Filter by parish e.g. 'Kingston', 'St. Catherine'"),
    db: TransitDatabase = Depends(get_db),
):
    """Returns all bus stops, taxi ranks, and terminals."""
    stops = await db.get_stops(parish=parish)
    return {"count": len(stops), "stops": stops}


# ─── Journey fare lookup ──────────────────────────────────────────────────────

@router.get("/fare-lookup")
async def lookup_fare(
    from_stop: str = Query(..., description="Origin stop name"),
    to_stop:   str = Query(..., description="Destination stop name"),
    db: TransitDatabase = Depends(get_db),
):
    """
    Find the cheapest fare for a given origin → destination.
    Returns all available options sorted by price.
    """
    fares = await db.get_fares(origin=from_stop, destination=to_stop)

    if not fares:
        # Try reverse (some routes are stored origin→dest only one way)
        fares = await db.get_fares(origin=to_stop, destination=from_stop)

    if not fares:
        return {
            "from":     from_stop,
            "to":       to_stop,
            "options":  [],
            "message":  "No direct fare found. You may need to transfer.",
        }

    # Sort by price ascending
    fares_sorted = sorted(fares, key=lambda f: f.get("amount_jmd") or 9999)

    return {
        "from":         from_stop,
        "to":           to_stop,
        "cheapest_jmd": fares_sorted[0].get("amount_jmd"),
        "options":      fares_sorted,
    }


# ─── Scrape status ────────────────────────────────────────────────────────────

@router.get("/status")
async def scrape_status():
    """Returns the latest scrape run summary."""
    latest_file = Path("data/snapshots/latest.json")
    if not latest_file.exists():
        return {"status": "no_scrape_run_yet", "message": "Run POST /transit/scrape to trigger first scrape"}
    data = json.loads(latest_file.read_text())
    return {"status": "ok", **data}


# ─── Manual scrape trigger (admin) ────────────────────────────────────────────

@router.post("/scrape")
async def trigger_scrape(
    background_tasks: BackgroundTasks,
    source: Optional[str] = Query(None, description="Scrape only this source, e.g. 'jutc'"),
    db: TransitDatabase = Depends(get_db),
):
    """
    Manually trigger a scrape run. Runs in background, returns immediately.
    Use GET /transit/status to check progress.
    """
    async def do_scrape():
        if source:
            from scheduler.orchestrator import SCRAPERS as ALL
            filtered = [c for c in ALL if c.__new__(c).source_name == source]
            if not filtered:
                return
            # Temporarily override SCRAPERS for this run
            import scheduler.orchestrator as orch
            original = orch.SCRAPERS
            orch.SCRAPERS = filtered
            await run_all_scrapers(db)
            orch.SCRAPERS = original
        else:
            await run_all_scrapers(db)

    background_tasks.add_task(do_scrape)
    return {
        "message": f"Scrape triggered {'for ' + source if source else '(all sources)'}. Check /transit/status for results.",
        "status":  "running",
    }
