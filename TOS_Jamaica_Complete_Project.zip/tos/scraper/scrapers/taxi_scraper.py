"""
Route Taxi & Intercity Carrier Scrapers
──────────────────────────────────────────────────────────────────────────────
Covers:
  • Route taxis (JUTA/JCAL licensed taxis on fixed routes)
  • Knutsford Express  (Kingston ↔ Montego Bay, Ocho Rios, Mandeville)
  • Jamaica Tours / charter bus operators

Route taxi fares are government-regulated by the ODPEM/OUR but change
periodically — this scraper checks OUR's website and known taxi-fare pages.
"""

import re
import logging
from .base_scraper import BaseScraper

logger = logging.getLogger(__name__)

# ── Route Taxi Fares ──────────────────────────────────────────────────────────

class RouteTaxiFareScraper(BaseScraper):
    """
    Scrapes regulated route taxi fares.
    Primary source: OUR (Office of Utilities Regulation) Jamaica fare notices.
    Fallback: hardcoded last-known fares.
    """

    source_name = "route_taxi"
    data_type   = "fares"

    OUR_URL = "https://www.our.org.jm/transportation"

    async def scrape(self) -> list[dict]:
        fares = []
        try:
            resp = await self.get(self.OUR_URL)
            soup = self.parse_html(resp.text)

            # OUR posts fare tables as PDFs AND HTML tables — try HTML first
            for table in soup.select("table"):
                rows = table.find_all("tr")
                for row in rows[1:]:  # skip header
                    cells = [c.get_text(strip=True) for c in row.find_all(["td","th"])]
                    if len(cells) >= 3:
                        amount = self._extract_amount(cells)
                        if amount:
                            fares.append({
                                "operator":       "Route Taxi",
                                "route":          cells[0],
                                "origin":         cells[1] if len(cells) > 1 else "",
                                "destination":    cells[2] if len(cells) > 2 else "",
                                "amount_jmd":     amount,
                                "currency":       "JMD",
                                "payment_type":   "cash",
                                "regulated":      True,
                                "regulator":      "OUR",
                            })

        except Exception as e:
            logger.warning(f"[route_taxi] OUR scrape failed: {e} — using known fares")

        if not fares:
            fares = self._known_route_taxi_fares()

        return fares

    def _extract_amount(self, cells: list[str]):
        for cell in reversed(cells):
            cleaned = re.sub(r"[^0-9.]", "", cell)
            try:
                val = float(cleaned)
                if 50 < val < 5000:  # sanity check for JMD fare range
                    return val
            except ValueError:
                continue
        return None

    def _known_route_taxi_fares(self) -> list[dict]:
        """
        Known route taxi fares as of 2026-03.
        Source: OUR fare notice + field verification.
        """
        base = {"operator": "Route Taxi", "currency": "JMD", "payment_type": "cash", "regulated": True, "regulator": "OUR"}
        return [
            {**base, "route": "Kingston → Half Way Tree",        "origin": "Downtown Kingston", "destination": "Half Way Tree",         "amount_jmd": 150.0},
            {**base, "route": "Half Way Tree → Papine",           "origin": "Half Way Tree",     "destination": "Papine",                "amount_jmd": 150.0},
            {**base, "route": "Half Way Tree → New Kingston",     "origin": "Half Way Tree",     "destination": "New Kingston",          "amount_jmd": 100.0},
            {**base, "route": "Kingston → Portmore",              "origin": "Downtown Kingston", "destination": "Portmore",              "amount_jmd": 300.0},
            {**base, "route": "Kingston → Spanish Town",          "origin": "Downtown Kingston", "destination": "Spanish Town",          "amount_jmd": 350.0},
            {**base, "route": "Half Way Tree → Constant Spring",  "origin": "Half Way Tree",     "destination": "Constant Spring",       "amount_jmd": 200.0},
            {**base, "route": "Half Way Tree → Liguanea",         "origin": "Half Way Tree",     "destination": "Liguanea",              "amount_jmd": 150.0},
            {**base, "route": "Half Way Tree → Barbican",         "origin": "Half Way Tree",     "destination": "Barbican",              "amount_jmd": 200.0},
            {**base, "route": "New Kingston → Constant Spring",   "origin": "New Kingston",      "destination": "Constant Spring",       "amount_jmd": 250.0},
            {**base, "route": "Spanish Town → Old Harbour",       "origin": "Spanish Town",      "destination": "Old Harbour",           "amount_jmd": 350.0},
            {**base, "route": "Montego Bay → Ocho Rios",          "origin": "Montego Bay",       "destination": "Ocho Rios",             "amount_jmd": 700.0},
            {**base, "route": "Montego Bay → Falmouth",           "origin": "Montego Bay",       "destination": "Falmouth",              "amount_jmd": 400.0},
            {**base, "route": "Kingston → Mandeville",            "origin": "Downtown Kingston", "destination": "Mandeville",            "amount_jmd": 900.0},
            {**base, "route": "Kingston → Ocho Rios",             "origin": "Downtown Kingston", "destination": "Ocho Rios",             "amount_jmd": 950.0},
            {**base, "route": "Kingston → Montego Bay",           "origin": "Downtown Kingston", "destination": "Montego Bay",           "amount_jmd": 1400.0},
        ]


# ── Knutsford Express ─────────────────────────────────────────────────────────

class KnutsfordExpressScraper(BaseScraper):
    """
    Scrapes Knutsford Express intercity bus schedules and fares.
    Source: https://www.knutsfordexpress.com
    """

    source_name = "knutsford_express"
    data_type   = "schedules"

    BASE_URL = "https://www.knutsfordexpress.com"

    async def scrape(self) -> list[dict]:
        schedules = []
        try:
            resp = await self.get(f"{self.BASE_URL}/schedules")
            soup = self.parse_html(resp.text)

            # Knutsford typically shows schedules in a table or accordion
            for row in soup.select("table tr, .schedule-row, .trip-row"):
                cells = [c.get_text(strip=True) for c in row.find_all(["td","th"])]
                if len(cells) >= 4 and cells[0] and cells[0] != "Route":
                    schedules.append({
                        "operator":      "Knutsford Express",
                        "transport_type":"intercity_bus",
                        "route":         cells[0],
                        "origin":        cells[1] if len(cells) > 1 else "",
                        "destination":   cells[2] if len(cells) > 2 else "",
                        "departure":     cells[3] if len(cells) > 3 else "",
                        "arrival":       cells[4] if len(cells) > 4 else "",
                        "fare_usd":      None,
                        "fare_jmd":      None,
                        "booking_url":   self.BASE_URL,
                    })

        except Exception as e:
            logger.warning(f"[knutsford] Scrape failed: {e} — using known schedules")

        if not schedules:
            schedules = self._known_knutsford_schedules()

        return schedules

    def _known_knutsford_schedules(self) -> list[dict]:
        base = {"operator": "Knutsford Express", "transport_type": "intercity_bus", "booking_url": "https://www.knutsfordexpress.com"}
        return [
            {**base, "route": "KGN-MBJ", "origin": "Kingston",     "destination": "Montego Bay",  "departure": "06:00", "arrival": "~10:30", "fare_usd": 25.0, "fare_jmd": 3900.0},
            {**base, "route": "KGN-MBJ", "origin": "Kingston",     "destination": "Montego Bay",  "departure": "08:00", "arrival": "~12:30", "fare_usd": 25.0, "fare_jmd": 3900.0},
            {**base, "route": "KGN-MBJ", "origin": "Kingston",     "destination": "Montego Bay",  "departure": "14:00", "arrival": "~18:30", "fare_usd": 25.0, "fare_jmd": 3900.0},
            {**base, "route": "MBJ-KGN", "origin": "Montego Bay",  "destination": "Kingston",     "departure": "06:00", "arrival": "~10:30", "fare_usd": 25.0, "fare_jmd": 3900.0},
            {**base, "route": "MBJ-KGN", "origin": "Montego Bay",  "destination": "Kingston",     "departure": "12:00", "arrival": "~16:30", "fare_usd": 25.0, "fare_jmd": 3900.0},
            {**base, "route": "KGN-OCR", "origin": "Kingston",     "destination": "Ocho Rios",    "departure": "07:00", "arrival": "~09:30", "fare_usd": 15.0, "fare_jmd": 2400.0},
            {**base, "route": "OCR-KGN", "origin": "Ocho Rios",    "destination": "Kingston",     "departure": "17:00", "arrival": "~19:30", "fare_usd": 15.0, "fare_jmd": 2400.0},
            {**base, "route": "KGN-MVL", "origin": "Kingston",     "destination": "Mandeville",   "departure": "08:00", "arrival": "~10:30", "fare_usd": 12.0, "fare_jmd": 1900.0},
            {**base, "route": "MVL-KGN", "origin": "Mandeville",   "destination": "Kingston",     "departure": "16:00", "arrival": "~18:30", "fare_usd": 12.0, "fare_jmd": 1900.0},
        ]


class KnutsfordExpressFareScraper(BaseScraper):
    """Scrapes current Knutsford Express fares from their booking page."""

    source_name = "knutsford_express"
    data_type   = "fares"

    BASE_URL = "https://www.knutsfordexpress.com"

    async def scrape(self) -> list[dict]:
        fares = []
        try:
            resp = await self.get(f"{self.BASE_URL}/fares")
            soup = self.parse_html(resp.text)
            for row in soup.select("table tr"):
                cells = [c.get_text(strip=True) for c in row.find_all(["td","th"])]
                if len(cells) >= 2:
                    amounts = [re.sub(r"[^0-9.]", "", c) for c in cells]
                    amounts = [float(a) for a in amounts if a and float(a) > 100]
                    if amounts:
                        fares.append({
                            "operator":   "Knutsford Express",
                            "route":      cells[0],
                            "amount_jmd": amounts[0] if amounts else None,
                            "currency":   "JMD",
                        })
        except Exception as e:
            logger.warning(f"[knutsford:fares] {e}")

        return fares
