"""
Transit Scraper — Base Scraper
──────────────────────────────────────────────────────────────────────────────
All scrapers inherit from BaseScraper which handles:
  • Rotating user-agents to avoid blocks
  • Retry logic with exponential backoff
  • Rate limiting (polite delays between requests)
  • Session management
  • Structured logging per scraper run
  • Change detection (hash comparison vs last scrape)
"""

import hashlib
import json
import logging
import random
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Optional

import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# Rotate these so repeated runs look like different browsers
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
]


@dataclass
class ScrapeResult:
    """Standardised result object returned by every scraper."""
    source:       str                    # e.g. "jutc", "knutford_express"
    data_type:    str                    # "routes" | "fares" | "stops" | "schedules"
    records:      list[dict]             # the actual scraped data
    scraped_at:   str = field(default_factory=lambda: datetime.utcnow().isoformat())
    record_count: int = 0
    changed:      bool = True            # False if data matches previous scrape
    error:        Optional[str] = None
    content_hash: Optional[str] = None  # SHA-256 of serialised records

    def __post_init__(self):
        self.record_count = len(self.records)
        if self.records:
            payload = json.dumps(self.records, sort_keys=True)
            self.content_hash = hashlib.sha256(payload.encode()).hexdigest()

    def to_dict(self):
        return asdict(self)


class BaseScraper(ABC):
    """
    Abstract base class for all transit data scrapers.

    Subclasses must implement:
        source_name  (str property)
        data_type    (str property)
        scrape()     (async method returning list[dict])
    """

    # Seconds to wait between requests — be polite
    REQUEST_DELAY = (1.5, 3.5)
    MAX_RETRIES   = 3
    TIMEOUT       = 20  # seconds

    def __init__(self):
        self.session: Optional[httpx.AsyncClient] = None
        self._last_hash: Optional[str] = None

    @property
    @abstractmethod
    def source_name(self) -> str:
        """Unique identifier for this data source, e.g. 'jutc'"""
        ...

    @property
    @abstractmethod
    def data_type(self) -> str:
        """What kind of data, e.g. 'routes', 'fares', 'stops', 'schedules'"""
        ...

    @abstractmethod
    async def scrape(self) -> list[dict]:
        """Perform the actual scrape and return raw records."""
        ...

    # ── Public entry point ────────────────────────────────────────────────────

    async def run(self, previous_hash: Optional[str] = None) -> ScrapeResult:
        """
        Full scrape cycle: open session → scrape → detect changes → return result.
        previous_hash: content hash from last run (stored in DB). If data hasn't
        changed the result will have changed=False so callers can skip DB writes.
        """
        self._last_hash = previous_hash
        async with httpx.AsyncClient(
            headers   = {"User-Agent": random.choice(USER_AGENTS)},
            timeout   = self.TIMEOUT,
            follow_redirects = True,
        ) as client:
            self.session = client
            try:
                logger.info(f"[{self.source_name}] Starting scrape ({self.data_type})")
                records = await self._scrape_with_retry()
                result  = ScrapeResult(
                    source    = self.source_name,
                    data_type = self.data_type,
                    records   = records,
                )
                # Mark unchanged if hash matches previous run
                if previous_hash and result.content_hash == previous_hash:
                    result.changed = False
                    logger.info(f"[{self.source_name}] No changes detected — skipping DB write")
                else:
                    logger.info(f"[{self.source_name}] ✅ {result.record_count} records scraped (changed={result.changed})")
                return result

            except Exception as e:
                logger.error(f"[{self.source_name}] ❌ Scrape failed: {e}")
                return ScrapeResult(
                    source    = self.source_name,
                    data_type = self.data_type,
                    records   = [],
                    error     = str(e),
                    changed   = False,
                )
            finally:
                self.session = None

    # ── Helpers available to subclasses ──────────────────────────────────────

    async def _scrape_with_retry(self) -> list[dict]:
        """Wrap scrape() with exponential backoff retry."""
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                return await self.scrape()
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                wait = 2 ** attempt + random.uniform(0, 1)
                logger.warning(f"[{self.source_name}] Attempt {attempt} failed: {e}. Retrying in {wait:.1f}s")
                if attempt == self.MAX_RETRIES:
                    raise
                time.sleep(wait)

    async def get(self, url: str, **kwargs) -> httpx.Response:
        """Rate-limited GET with random delay."""
        delay = random.uniform(*self.REQUEST_DELAY)
        time.sleep(delay)
        response = await self.session.get(url, **kwargs)
        response.raise_for_status()
        return response

    async def post(self, url: str, **kwargs) -> httpx.Response:
        """Rate-limited POST."""
        delay = random.uniform(*self.REQUEST_DELAY)
        time.sleep(delay)
        response = await self.session.post(url, **kwargs)
        response.raise_for_status()
        return response

    def parse_html(self, html: str) -> BeautifulSoup:
        return BeautifulSoup(html, "lxml")
