"""
JUTC Scraper
──────────────────────────────────────────────────────────────────────────────
Scrapes the Jamaica Urban Transit Company website for:
  • Bus routes (route number, name, origin → destination)
  • Bus stops (name, location, routes that serve it)
  • Schedules (first/last bus, frequency by time of day)
  • Fares (flat fare structure + zone info)

Source: https://www.jutc.com.jm

NOTE: If JUTC ever adds a public API or GTFS feed, prefer that over scraping.
This scraper handles the current HTML-only site as of 2026.
"""

import re
import logging
from typing import Optional
from .base_scraper import BaseScraper

logger = logging.getLogger(__name__)

JUTC_BASE = "https://www.jutc.com.jm"


class JUTCRouteScraper(BaseScraper):
    """Scrapes all bus routes from the JUTC website."""

    source_name = "jutc"
    data_type   = "routes"

    async def scrape(self) -> list[dict]:
        routes = []
        try:
            resp = await self.get(f"{JUTC_BASE}/routes")
            soup = self.parse_html(resp.text)

            # JUTC route tables — adapt selectors to actual page structure
            route_rows = soup.select("table.route-table tr, .route-list .route-item, table tr")

            for row in route_rows:
                cells = row.find_all(["td", "th"])
                if len(cells) < 3:
                    continue

                route_num = cells[0].get_text(strip=True)
                if not route_num or not route_num[0].isdigit():
                    continue  # skip header rows

                route = {
                    "route_number":  route_num,
                    "route_name":    cells[1].get_text(strip=True) if len(cells) > 1 else "",
                    "origin":        cells[2].get_text(strip=True) if len(cells) > 2 else "",
                    "destination":   cells[3].get_text(strip=True) if len(cells) > 3 else "",
                    "zone":          cells[4].get_text(strip=True) if len(cells) > 4 else "",
                    "operator":      "JUTC",
                    "transport_type": "bus",
                }
                routes.append(route)

            logger.info(f"[jutc] Found {len(routes)} routes")

        except Exception as e:
            logger.error(f"[jutc:routes] Error: {e}")
            # Return partial data if we got any, don't crash whole run
            pass

        # Always supplement with known static JUTC routes as fallback
        if not routes:
            routes = self._known_jutc_routes()

        return routes

    def _known_jutc_routes(self) -> list[dict]:
        """
        Hardcoded fallback for major JUTC routes.
        Updated manually when JUTC publishes changes.
        Last verified: 2026-03
        """
        return [
            {"route_number": "22", "route_name": "Half Way Tree – Downtown",     "origin": "Half Way Tree",      "destination": "Downtown Kingston",  "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "22A","route_name": "Half Way Tree – Downtown Alt",  "origin": "Half Way Tree",      "destination": "Downtown Kingston",  "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "24", "route_name": "Papine – Downtown",             "origin": "Papine",             "destination": "Downtown Kingston",  "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "38", "route_name": "Portmore – Half Way Tree",      "origin": "Portmore",           "destination": "Half Way Tree",      "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "45", "route_name": "Spanish Town – Downtown",       "origin": "Spanish Town",       "destination": "Downtown Kingston",  "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "99", "route_name": "Waterford – Half Way Tree",     "origin": "Waterford",          "destination": "Half Way Tree",      "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "72", "route_name": "Constant Spring – Downtown",    "origin": "Constant Spring",    "destination": "Downtown Kingston",  "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "21", "route_name": "Barbican – Half Way Tree",      "origin": "Barbican",           "destination": "Half Way Tree",      "operator": "JUTC", "transport_type": "bus"},
            {"route_number": "63", "route_name": "Havendale – Downtown",          "origin": "Havendale",          "destination": "Downtown Kingston",  "operator": "JUTC", "transport_type": "bus"},
        ]


class JUTCFareScraper(BaseScraper):
    """Scrapes JUTC fare structure."""

    source_name = "jutc"
    data_type   = "fares"

    async def scrape(self) -> list[dict]:
        fares = []
        try:
            resp = await self.get(f"{JUTC_BASE}/fares")
            soup = self.parse_html(resp.text)

            fare_tables = soup.select("table")
            for table in fare_tables:
                rows = table.find_all("tr")
                for row in rows:
                    cells = row.find_all(["td", "th"])
                    text  = [c.get_text(strip=True) for c in cells]

                    # Look for rows that contain dollar amounts
                    amounts = [t for t in text if re.match(r"\$?[\d,]+", t)]
                    if amounts:
                        fares.append({
                            "operator":     "JUTC",
                            "fare_type":    text[0] if text else "Standard",
                            "amount_jmd":   self._parse_amount(amounts[0]),
                            "currency":     "JMD",
                            "payment_type": "cash",
                            "notes":        " | ".join(text),
                        })

        except Exception as e:
            logger.warning(f"[jutc:fares] Could not scrape live — using known fares: {e}")

        if not fares:
            fares = self._known_jutc_fares()

        return fares

    def _parse_amount(self, text: str) -> Optional[float]:
        cleaned = re.sub(r"[^0-9.]", "", text)
        try:
            return float(cleaned)
        except ValueError:
            return None

    def _known_jutc_fares(self) -> list[dict]:
        """Last verified JUTC fares — 2026-03."""
        return [
            {"operator": "JUTC", "fare_type": "Standard Adult",    "amount_jmd": 100.0, "currency": "JMD", "payment_type": "cash",       "notes": "All routes flat fare"},
            {"operator": "JUTC", "fare_type": "Concessionary",     "amount_jmd": 50.0,  "currency": "JMD", "payment_type": "cash",       "notes": "Seniors, students, disabled"},
            {"operator": "JUTC", "fare_type": "Child (under 12)",  "amount_jmd": 50.0,  "currency": "JMD", "payment_type": "cash",       "notes": "Under 12 with adult"},
            {"operator": "JUTC", "fare_type": "Tap Card Adult",    "amount_jmd": 90.0,  "currency": "JMD", "payment_type": "tap_card",   "notes": "Discounted with JUTC tap card"},
            {"operator": "JUTC", "fare_type": "Tap Card Student",  "amount_jmd": 45.0,  "currency": "JMD", "payment_type": "tap_card",   "notes": "Student card discount"},
        ]


class JUTCStopScraper(BaseScraper):
    """Scrapes JUTC bus stop/terminal locations."""

    source_name = "jutc"
    data_type   = "stops"

    async def scrape(self) -> list[dict]:
        stops = []
        try:
            resp = await self.get(f"{JUTC_BASE}/stops")
            soup = self.parse_html(resp.text)

            for item in soup.select(".stop-item, .terminal-item, table tr"):
                cells = item.find_all(["td", "li"])
                if not cells:
                    continue
                name = item.get_text(strip=True)
                if len(name) > 3:
                    stops.append({
                        "name":           cells[0].get_text(strip=True) if cells else name,
                        "type":           "bus_stop",
                        "operator":       "JUTC",
                        "parish":         self._infer_parish(name),
                        "latitude":       None,
                        "longitude":      None,
                        "routes_served":  [],
                    })
        except Exception as e:
            logger.warning(f"[jutc:stops] Falling back to known stops: {e}")

        if not stops:
            stops = self._known_jutc_terminals()

        return stops

    def _infer_parish(self, name: str) -> str:
        """Infer parish from stop name keywords."""
        mapping = {
            "Kingston": ["Downtown", "Half Way Tree", "Papine", "Barbican", "Havendale", "Constant Spring"],
            "St. Andrew": ["Matilda's Corner", "August Town", "Gordon Town"],
            "St. Catherine": ["Spanish Town", "Portmore", "Old Harbour", "Waterford", "Gregory Park"],
            "St. James": ["Montego Bay", "Rose Hall"],
        }
        for parish, keywords in mapping.items():
            if any(k.lower() in name.lower() for k in keywords):
                return parish
        return "Unknown"

    def _known_jutc_terminals(self) -> list[dict]:
        return [
            {"name": "Half Way Tree Transport Centre", "type": "terminal",  "operator": "JUTC", "parish": "Kingston",     "latitude": 17.9939, "longitude": -76.7894, "routes_served": ["22","24","21","63","99"]},
            {"name": "Downtown Kingston Terminal",     "type": "terminal",  "operator": "JUTC", "parish": "Kingston",     "latitude": 17.9970, "longitude": -76.7936, "routes_served": ["22","38","45","72"]},
            {"name": "Papine Square",                  "type": "terminal",  "operator": "JUTC", "parish": "St. Andrew",   "latitude": 18.0178, "longitude": -76.7497, "routes_served": ["24"]},
            {"name": "Spanish Town Bus Park",          "type": "terminal",  "operator": "JUTC", "parish": "St. Catherine","latitude": 17.9909, "longitude": -76.9549, "routes_served": ["45"]},
            {"name": "Portmore Bus Terminal",          "type": "terminal",  "operator": "JUTC", "parish": "St. Catherine","latitude": 17.9503, "longitude": -76.8839, "routes_served": ["38"]},
            {"name": "Constant Spring Square",         "type": "bus_stop",  "operator": "JUTC", "parish": "St. Andrew",   "latitude": 18.0322, "longitude": -76.7955, "routes_served": ["72"]},
        ]
