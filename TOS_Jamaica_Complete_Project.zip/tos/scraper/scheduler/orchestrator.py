"""
Transit Scraper — Weekly Orchestrator
──────────────────────────────────────────────────────────────────────────────
Runs all scrapers on a weekly schedule (every Sunday at 2:00 AM).

Flow per run:
  1. Load previous content hashes from DB (skip unchanged sources)
  2. Run all scrapers concurrently (with rate limiting per domain)
  3. Persist changed records to PostgreSQL
  4. Write full snapshot to JSON file (as backup / for API use)
  5. Generate a run report (what changed, what failed)
  6. (Optional) POST a webhook summary to your app

Run manually:
  python -m scheduler.orchestrator --run-now

Run as cron:
  0 2 * * 0  cd /path/to/transit-scraper && python -m scheduler.orchestrator
"""

import asyncio
import json
import logging
import os
import argparse
from datetime import datetime
from pathlib import Path
from typing import Optional

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

# Import all scrapers
from scrapers.jutc_scraper      import JUTCRouteScraper, JUTCFareScraper, JUTCStopScraper
from scrapers.taxi_scraper      import RouteTaxiFareScraper, KnutsfordExpressScraper, KnutsfordExpressFareScraper
from scrapers.base_scraper      import ScrapeResult
from storage.database           import TransitDatabase

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt = "%Y-%m-%d %H:%M:%S",
)
logger    = logging.getLogger("orchestrator")
scheduler = AsyncIOScheduler(timezone="America/Jamaica")

SNAPSHOT_DIR = Path("data/snapshots")
SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)

# ─── Scraper registry ─────────────────────────────────────────────────────────
# Add new scrapers here — they'll automatically be picked up by the scheduler.

SCRAPERS = [
    JUTCRouteScraper,
    JUTCFareScraper,
    JUTCStopScraper,
    RouteTaxiFareScraper,
    KnutsfordExpressScraper,
    KnutsfordExpressFareScraper,
]


# ─── Main scrape run ──────────────────────────────────────────────────────────

async def run_all_scrapers(db: Optional[TransitDatabase] = None) -> dict:
    """
    Execute all registered scrapers and persist results.
    Returns a summary report dict.
    """
    run_id     = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    started_at = datetime.utcnow()
    logger.info(f"═══ Scrape run {run_id} started — {len(SCRAPERS)} scrapers ═══")

    # Load previous hashes to detect changes
    prev_hashes = await db.get_content_hashes() if db else {}

    # Run scrapers concurrently — grouped by domain to avoid hammering one server
    domain_groups = _group_by_domain(SCRAPERS)
    all_results: list[ScrapeResult] = []

    for domain, scraper_classes in domain_groups.items():
        logger.info(f"  Running {len(scraper_classes)} scrapers for domain: {domain}")
        # Within same domain: sequential (polite). Across domains: concurrent.
        for scraper_class in scraper_classes:
            scraper  = scraper_class()
            hash_key = f"{scraper.source_name}:{scraper.data_type}"
            prev_hash = prev_hashes.get(hash_key)
            result   = await scraper.run(previous_hash=prev_hash)
            all_results.append(result)

            # Persist to DB if data changed
            if result.changed and result.records and db:
                await db.upsert_records(result)
                await db.save_content_hash(hash_key, result.content_hash)
                logger.info(f"  ✅ Saved {result.record_count} {result.data_type} records from {result.source}")

    # Save full snapshot to disk
    snapshot_path = SNAPSHOT_DIR / f"snapshot_{run_id}.json"
    _save_snapshot(all_results, snapshot_path)

    # Build summary report
    report = _build_report(run_id, started_at, all_results)
    logger.info(f"═══ Run complete — {report['changed']} sources updated, {report['failed']} failed ═══")

    # Save latest snapshot reference
    (SNAPSHOT_DIR / "latest.json").write_text(
        json.dumps({"latest_snapshot": str(snapshot_path), "run_id": run_id, "report": report}, indent=2)
    )

    return report


def _group_by_domain(scraper_classes: list) -> dict:
    """Group scrapers by their source domain to rate-limit per server."""
    domain_map = {
        "jutc":             ["jutc"],
        "our":              ["route_taxi"],
        "knutsford_express":["knutsford_express"],
    }
    groups = {}
    for cls in scraper_classes:
        instance = cls.__new__(cls)
        source   = instance.source_name
        domain   = next((d for d, sources in domain_map.items() if source in sources), source)
        groups.setdefault(domain, []).append(cls)
    return groups


def _save_snapshot(results: list[ScrapeResult], path: Path):
    """Write all scraped data to a single JSON file."""
    snapshot = {
        "generated_at": datetime.utcnow().isoformat(),
        "sources": {}
    }
    for r in results:
        key = f"{r.source}:{r.data_type}"
        snapshot["sources"][key] = {
            "record_count": r.record_count,
            "changed":      r.changed,
            "scraped_at":   r.scraped_at,
            "error":        r.error,
            "records":      r.records,
        }
    path.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False))
    logger.info(f"Snapshot saved → {path}")


def _build_report(run_id: str, started_at: datetime, results: list[ScrapeResult]) -> dict:
    duration = (datetime.utcnow() - started_at).total_seconds()
    changed  = [r for r in results if r.changed and not r.error]
    failed   = [r for r in results if r.error]
    unchanged= [r for r in results if not r.changed and not r.error]

    return {
        "run_id":         run_id,
        "duration_secs":  round(duration, 1),
        "total_scrapers": len(results),
        "changed":        len(changed),
        "unchanged":      len(unchanged),
        "failed":         len(failed),
        "total_records":  sum(r.record_count for r in results),
        "changed_sources":[f"{r.source}:{r.data_type}" for r in changed],
        "failed_sources": [{"source": r.source, "error": r.error} for r in failed],
    }


# ─── Scheduler setup ──────────────────────────────────────────────────────────

def start_scheduler():
    db = TransitDatabase()

    # Weekly: every Sunday at 2:00 AM Jamaica time
    scheduler.add_job(
        lambda: asyncio.create_task(run_all_scrapers(db)),
        trigger = CronTrigger(day_of_week="sun", hour=2, minute=0),
        id      = "weekly_scrape",
        name    = "Weekly Transit Data Scrape",
        replace_existing = True,
        misfire_grace_time = 3600,  # run up to 1 hour late if server was down
    )

    scheduler.start()
    logger.info("✅ Weekly scrape scheduler started — runs every Sunday at 2:00 AM")


# ─── CLI entry point ──────────────────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser(description="Transit Scraper Orchestrator")
    parser.add_argument("--run-now",    action="store_true", help="Run all scrapers immediately")
    parser.add_argument("--schedule",   action="store_true", help="Start the weekly scheduler (blocking)")
    parser.add_argument("--source",     type=str,            help="Run only a specific source (e.g. jutc)")
    args = parser.parse_args()

    db = TransitDatabase()
    await db.init()

    if args.run_now or args.source:
        if args.source:
            # Filter to specific source
            filtered = [c for c in SCRAPERS if c.__new__(c).source_name == args.source]
            if not filtered:
                print(f"Unknown source '{args.source}'. Available: {[c.__new__(c).source_name for c in SCRAPERS]}")
                return
            global SCRAPERS
            SCRAPERS = filtered
        report = await run_all_scrapers(db)
        print(json.dumps(report, indent=2))

    elif args.schedule:
        start_scheduler()
        try:
            # Keep process alive
            while True:
                await asyncio.sleep(3600)
        except (KeyboardInterrupt, SystemExit):
            scheduler.shutdown()
            logger.info("Scheduler stopped")
    else:
        parser.print_help()


if __name__ == "__main__":
    asyncio.run(main())
