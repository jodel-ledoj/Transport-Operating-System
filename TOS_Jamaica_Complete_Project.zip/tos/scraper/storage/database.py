"""
Transit Scraper — Database Storage Layer
──────────────────────────────────────────────────────────────────────────────
Stores scraped data in PostgreSQL with:
  • Upsert logic — update existing records, insert new ones, never duplicate
  • Content hash tracking — fast change detection per source+data_type
  • Scrape run history log — every run is recorded with its report
  • Full history retention — old records are archived, not deleted
"""

import json
import logging
import os
from datetime import datetime
from typing import Optional

import asyncpg
from scrapers.base_scraper import ScrapeResult

logger = logging.getLogger(__name__)

DATABASE_URL = os.getenv(
    "TRANSIT_DB_URL",
    "postgresql://postgres:password@localhost:5432/transit_data"
)

SCHEMA = """
-- ── Routes ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS routes (
    id              SERIAL PRIMARY KEY,
    source          VARCHAR(100) NOT NULL,
    route_number    VARCHAR(20),
    route_name      TEXT,
    origin          TEXT,
    destination     TEXT,
    operator        VARCHAR(100),
    transport_type  VARCHAR(50),
    zone            VARCHAR(50),
    is_active       BOOLEAN DEFAULT TRUE,
    first_seen      TIMESTAMPTZ DEFAULT NOW(),
    last_updated    TIMESTAMPTZ DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, route_number, operator)
);

-- ── Fares ─────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fares (
    id              SERIAL PRIMARY KEY,
    source          VARCHAR(100) NOT NULL,
    operator        VARCHAR(100),
    route           TEXT,
    origin          TEXT,
    destination     TEXT,
    fare_type       VARCHAR(100),
    amount_jmd      NUMERIC(10,2),
    amount_usd      NUMERIC(10,2),
    currency        VARCHAR(10) DEFAULT 'JMD',
    payment_type    VARCHAR(50),
    regulated       BOOLEAN DEFAULT FALSE,
    regulator       VARCHAR(100),
    effective_date  DATE,
    is_current      BOOLEAN DEFAULT TRUE,
    first_seen      TIMESTAMPTZ DEFAULT NOW(),
    last_updated    TIMESTAMPTZ DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, operator, route, fare_type)
);

-- ── Stops / Terminals ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stops (
    id              SERIAL PRIMARY KEY,
    source          VARCHAR(100) NOT NULL,
    name            TEXT NOT NULL,
    stop_type       VARCHAR(50),  -- bus_stop | terminal | rank
    operator        VARCHAR(100),
    parish          VARCHAR(100),
    latitude        NUMERIC(10,7),
    longitude       NUMERIC(10,7),
    routes_served   JSONB,        -- array of route numbers
    is_active       BOOLEAN DEFAULT TRUE,
    first_seen      TIMESTAMPTZ DEFAULT NOW(),
    last_updated    TIMESTAMPTZ DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, name, operator)
);

-- ── Schedules ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS schedules (
    id              SERIAL PRIMARY KEY,
    source          VARCHAR(100) NOT NULL,
    operator        VARCHAR(100),
    route           TEXT,
    origin          TEXT,
    destination     TEXT,
    departure_time  VARCHAR(20),
    arrival_time    VARCHAR(20),
    days_of_week    JSONB,        -- ["mon","tue","wed","thu","fri"]
    fare_jmd        NUMERIC(10,2),
    fare_usd        NUMERIC(10,2),
    booking_url     TEXT,
    is_active       BOOLEAN DEFAULT TRUE,
    first_seen      TIMESTAMPTZ DEFAULT NOW(),
    last_updated    TIMESTAMPTZ DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, operator, route, departure_time)
);

-- ── Content hash tracking (change detection) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS scrape_hashes (
    source_key      VARCHAR(200) PRIMARY KEY,  -- "jutc:routes"
    content_hash    VARCHAR(64),
    record_count    INTEGER,
    last_updated    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Scrape run history log ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scrape_runs (
    id              SERIAL PRIMARY KEY,
    run_id          VARCHAR(50) NOT NULL,
    source          VARCHAR(100),
    data_type       VARCHAR(50),
    record_count    INTEGER DEFAULT 0,
    changed         BOOLEAN DEFAULT FALSE,
    error           TEXT,
    duration_secs   NUMERIC(8,2),
    scraped_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Indexes ───────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_routes_operator  ON routes(operator);
CREATE INDEX IF NOT EXISTS idx_fares_operator   ON fares(operator);
CREATE INDEX IF NOT EXISTS idx_fares_route      ON fares(route);
CREATE INDEX IF NOT EXISTS idx_stops_parish     ON stops(parish);
CREATE INDEX IF NOT EXISTS idx_schedules_route  ON schedules(route);
"""


class TransitDatabase:

    def __init__(self, url: str = DATABASE_URL):
        self.url  = url
        self._pool: Optional[asyncpg.Pool] = None

    async def init(self):
        """Connect and ensure schema exists."""
        self._pool = await asyncpg.create_pool(self.url, min_size=2, max_size=10)
        async with self._pool.acquire() as conn:
            await conn.execute(SCHEMA)
        logger.info("✅ Transit database ready")

    async def close(self):
        if self._pool:
            await self._pool.close()

    # ── Content hash tracking ─────────────────────────────────────────────────

    async def get_content_hashes(self) -> dict[str, str]:
        """Load all known content hashes. Used to skip unchanged sources."""
        async with self._pool.acquire() as conn:
            rows = await conn.fetch("SELECT source_key, content_hash FROM scrape_hashes")
            return {r["source_key"]: r["content_hash"] for r in rows}

    async def save_content_hash(self, source_key: str, content_hash: str, record_count: int = 0):
        async with self._pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO scrape_hashes (source_key, content_hash, record_count, last_updated)
                VALUES ($1, $2, $3, NOW())
                ON CONFLICT (source_key) DO UPDATE
                SET content_hash=$2, record_count=$3, last_updated=NOW()
            """, source_key, content_hash, record_count)

    # ── Upsert scraped records ────────────────────────────────────────────────

    async def upsert_records(self, result: ScrapeResult):
        """Route incoming records to the right table based on data_type."""
        handlers = {
            "routes":    self._upsert_routes,
            "fares":     self._upsert_fares,
            "stops":     self._upsert_stops,
            "schedules": self._upsert_schedules,
        }
        handler = handlers.get(result.data_type)
        if handler:
            await handler(result.source, result.records)
        else:
            logger.warning(f"No handler for data_type: {result.data_type}")

    async def _upsert_routes(self, source: str, records: list[dict]):
        async with self._pool.acquire() as conn:
            for r in records:
                await conn.execute("""
                    INSERT INTO routes (source, route_number, route_name, origin, destination,
                                        operator, transport_type, zone, last_updated, raw_data)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),$9)
                    ON CONFLICT (source, route_number, operator)
                    DO UPDATE SET route_name=$3, origin=$4, destination=$5,
                                  transport_type=$7, zone=$8, last_updated=NOW(), raw_data=$9
                """, source, r.get("route_number"), r.get("route_name"),
                     r.get("origin"), r.get("destination"), r.get("operator"),
                     r.get("transport_type"), r.get("zone"), json.dumps(r))

    async def _upsert_fares(self, source: str, records: list[dict]):
        async with self._pool.acquire() as conn:
            for r in records:
                await conn.execute("""
                    INSERT INTO fares (source, operator, route, origin, destination, fare_type,
                                       amount_jmd, amount_usd, currency, payment_type,
                                       regulated, regulator, is_current, last_updated, raw_data)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,TRUE,NOW(),$13)
                    ON CONFLICT (source, operator, route, fare_type)
                    DO UPDATE SET amount_jmd=$7, amount_usd=$8, currency=$9,
                                  payment_type=$10, regulated=$11, regulator=$12,
                                  is_current=TRUE, last_updated=NOW(), raw_data=$13
                """, source, r.get("operator"), r.get("route",""), r.get("origin"),
                     r.get("destination"), r.get("fare_type","Standard"),
                     r.get("amount_jmd"), r.get("amount_usd"), r.get("currency","JMD"),
                     r.get("payment_type"), r.get("regulated",False), r.get("regulator"),
                     json.dumps(r))

    async def _upsert_stops(self, source: str, records: list[dict]):
        async with self._pool.acquire() as conn:
            for r in records:
                await conn.execute("""
                    INSERT INTO stops (source, name, stop_type, operator, parish,
                                       latitude, longitude, routes_served, last_updated, raw_data)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),$9)
                    ON CONFLICT (source, name, operator)
                    DO UPDATE SET stop_type=$3, parish=$5, latitude=$6, longitude=$7,
                                  routes_served=$8, last_updated=NOW(), raw_data=$9
                """, source, r.get("name"), r.get("type"), r.get("operator"),
                     r.get("parish"), r.get("latitude"), r.get("longitude"),
                     json.dumps(r.get("routes_served",[])), json.dumps(r))

    async def _upsert_schedules(self, source: str, records: list[dict]):
        async with self._pool.acquire() as conn:
            for r in records:
                await conn.execute("""
                    INSERT INTO schedules (source, operator, route, origin, destination,
                                           departure_time, arrival_time, fare_jmd, fare_usd,
                                           booking_url, last_updated, raw_data)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,NOW(),$11)
                    ON CONFLICT (source, operator, route, departure_time)
                    DO UPDATE SET arrival_time=$7, fare_jmd=$8, fare_usd=$9,
                                  booking_url=$10, last_updated=NOW(), raw_data=$11
                """, source, r.get("operator"), r.get("route"), r.get("origin"),
                     r.get("destination"), r.get("departure"), r.get("arrival"),
                     r.get("fare_jmd"), r.get("fare_usd"), r.get("booking_url"),
                     json.dumps(r))

    # ── Query helpers ─────────────────────────────────────────────────────────

    async def get_fares(self, operator: str = None, origin: str = None, destination: str = None) -> list[dict]:
        async with self._pool.acquire() as conn:
            query  = "SELECT * FROM fares WHERE is_current=TRUE"
            params = []
            if operator:
                params.append(operator)
                query += f" AND operator ILIKE ${len(params)}"
            if origin:
                params.append(f"%{origin}%")
                query += f" AND origin ILIKE ${len(params)}"
            if destination:
                params.append(f"%{destination}%")
                query += f" AND destination ILIKE ${len(params)}"
            query += " ORDER BY operator, route"
            rows = await conn.fetch(query, *params)
            return [dict(r) for r in rows]

    async def get_routes(self, operator: str = None) -> list[dict]:
        async with self._pool.acquire() as conn:
            if operator:
                rows = await conn.fetch(
                    "SELECT * FROM routes WHERE is_active=TRUE AND operator ILIKE $1 ORDER BY route_number",
                    f"%{operator}%"
                )
            else:
                rows = await conn.fetch("SELECT * FROM routes WHERE is_active=TRUE ORDER BY operator, route_number")
            return [dict(r) for r in rows]

    async def get_stops(self, parish: str = None) -> list[dict]:
        async with self._pool.acquire() as conn:
            if parish:
                rows = await conn.fetch(
                    "SELECT * FROM stops WHERE is_active=TRUE AND parish ILIKE $1 ORDER BY name",
                    f"%{parish}%"
                )
            else:
                rows = await conn.fetch("SELECT * FROM stops WHERE is_active=TRUE ORDER BY parish, name")
            return [dict(r) for r in rows]
