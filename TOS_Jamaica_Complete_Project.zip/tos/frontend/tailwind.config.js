/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy:   { DEFAULT: "#1A3E5C", light: "#2A5A80", dark: "#0F2438" },
        teal:   { DEFAULT: "#0D7A7A", light: "#10A0A0", dark: "#086060" },
        gold:   { DEFAULT: "#C9A227", light: "#E5BE50", dark: "#9A7A1E" },
        safe:   "#2E7D32",
        caution:"#C9A227",
        danger: "#C62828",
      },
      fontFamily: { sans: ["Inter", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
