"use client";
import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { Bus, ArrowRight, Loader2, RotateCcw } from "lucide-react";
import toast from "react-hot-toast";
import { authApi } from "../../utils/api";
import { useAuthStore } from "../../store/authStore";

export default function VerifyPage() {
  const router      = useRouter();
  const { pendingPhone, setAuth } = useAuthStore();
  const [otp, setOtp]   = useState(["","","","","",""]);
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);

  const handleChange = (index: number, val: string) => {
    if (!/^[0-9]?$/.test(val)) return;
    const newOtp = [...otp];
    newOtp[index] = val;
    setOtp(newOtp);
    if (val && index < 5) inputs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = otp.join("");
    if (code.length !== 6) return;

    setLoading(true);
    try {
      const res = await authApi.verifyOtp(pendingPhone, code);
      setAuth(res.data.token, res.data.user);
      toast.success(`Welcome, ${res.data.user.name}!`);
      router.push("/dashboard");
    } catch (err: any) {
      toast.error(err.response?.data?.message || "Invalid code. Please try again.");
      setOtp(["","","","","",""]);
      inputs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (!pendingPhone) return;
    setResending(true);
    try {
      await authApi.register(pendingPhone, "User");
      toast.success("New code sent!");
    } catch {
      toast.error("Failed to resend. Please wait a moment.");
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1A3E5C] to-[#0D7A7A] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[#C9A227] rounded-2xl mb-4">
            <Bus className="w-9 h-9 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">Verify Your Number</h1>
          <p className="text-white/70 mt-2 text-sm">
            Enter the 6-digit code sent to<br />
            <span className="text-white font-semibold">{pendingPhone || "your phone"}</span>
          </p>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="flex gap-2 justify-center">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  ref={el => inputs.current[i] = el}
                  type="text" inputMode="numeric"
                  value={digit}
                  onChange={e => handleChange(i, e.target.value)}
                  onKeyDown={e => handleKeyDown(i, e)}
                  maxLength={1}
                  className="w-12 h-14 text-center text-2xl font-bold border-2 border-gray-200 rounded-xl
                             focus:border-[#0D7A7A] outline-none transition text-[#1A3E5C]"
                />
              ))}
            </div>

            <button
              type="submit"
              disabled={loading || otp.join("").length !== 6}
              className="w-full py-3.5 bg-[#1A3E5C] text-white rounded-xl font-bold hover:bg-[#0F2438] transition flex items-center justify-center gap-2 disabled:opacity-60">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Verify & Continue <ArrowRight className="w-5 h-5" /></>}
            </button>
          </form>

          <button
            onClick={handleResend} disabled={resending}
            className="w-full mt-4 py-2.5 text-sm text-gray-500 hover:text-[#0D7A7A] flex items-center justify-center gap-2 transition">
            <RotateCcw className="w-4 h-4" />
            {resending ? "Sending..." : "Resend code"}
          </button>
        </div>
      </div>
    </div>
  );
}
