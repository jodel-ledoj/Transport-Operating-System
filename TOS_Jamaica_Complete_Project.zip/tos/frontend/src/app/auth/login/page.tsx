"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Bus, Phone, ArrowRight, Loader2 } from "lucide-react";
import toast from "react-hot-toast";
import { authApi } from "../../utils/api";
import { useAuthStore } from "../../store/authStore";

export default function LoginPage() {
  const router = useRouter();
  const { setPending } = useAuthStore();
  const [phone,   setPhone]   = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await authApi.register(phone, "User");
      setPending(phone);
      toast.success("Verification code sent!");
      router.push("/auth/verify");
    } catch (err: any) {
      toast.error(err.response?.data?.message || "Couldn't send code. Check your number.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1A3E5C] to-[#0D7A7A] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[#C9A227] rounded-2xl mb-4">
            <Bus className="w-9 h-9 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">Welcome Back</h1>
          <p className="text-white/70 mt-2">Enter your number to log in</p>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-[#1A3E5C] mb-1.5">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                  placeholder="+1876XXXXXXX"
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-[#0D7A7A] outline-none transition text-[#1C1C1C]"
                  required
                />
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-3.5 bg-[#1A3E5C] text-white rounded-xl font-bold hover:bg-[#0F2438] transition flex items-center justify-center gap-2 disabled:opacity-60">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Send Code <ArrowRight className="w-5 h-5" /></>}
            </button>
          </form>
          <p className="text-center text-sm text-gray-500 mt-6">
            New to TOS?{" "}
            <Link href="/auth/register" className="text-[#0D7A7A] font-semibold hover:underline">Create account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
