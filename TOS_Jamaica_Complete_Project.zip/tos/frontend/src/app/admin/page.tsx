"use client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Users, Bus, DollarSign, MapPin,
         RefreshCw, BarChart3, AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import toast from "react-hot-toast";
import { adminApi, transitApi } from "../../utils/api";
import { useAuthStore } from "../../store/authStore";

export default function AdminPage() {
  const router = useRouter();
  const { user, isAdmin } = useAuthStore();

  useEffect(() => {
    if (user && !isAdmin()) { router.push("/dashboard"); }
  }, [user]);

  const { data: dashboard, isLoading } = useQuery({
    queryKey: ["admin-dashboard"],
    queryFn:  () => adminApi.dashboard().then(r => r.data),
  });

  const { data: transitStatus, refetch: refetchStatus } = useQuery({
    queryKey: ["transit-status"],
    queryFn:  () => transitApi.status().then(r => r.data),
  });

  const scrapeMutation = useMutation({
    mutationFn: () => transitApi.scrape(),
    onSuccess:  () => { toast.success("Scrape triggered! Check status in a moment."); refetchStatus(); },
    onError:    () => toast.error("Failed to trigger scrape."),
  });

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#F5F7FA]">
      <Loader2 className="w-8 h-8 animate-spin text-[#0D7A7A]" />
    </div>
  );

  const stats = dashboard?.stats || {};
  const scrapes = transitStatus?.scrapers || [];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <header className="bg-[#1A3E5C] text-white px-6 py-4 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold">TOS Admin Dashboard</h1>
          <p className="text-xs text-white/60">Transport Operating System — Jamaica</p>
        </div>
        <button onClick={() => scrapeMutation.mutate()} disabled={scrapeMutation.isPending}
          className="flex items-center gap-2 px-4 py-2 bg-[#C9A227] rounded-lg text-sm font-bold hover:bg-[#9A7A1E] transition disabled:opacity-60">
          {scrapeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          Run Scrape
        </button>
      </header>

      <div className="max-w-6xl mx-auto p-6 space-y-6">

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: <Users    className="w-6 h-6 text-[#0D7A7A]" />, label: "Total Users",    value: stats.totalUsers    || 0, color: "bg-[#0D7A7A]/10" },
            { icon: <Bus      className="w-6 h-6 text-[#1A3E5C]" />, label: "Active Routes",  value: stats.totalRoutes   || 0, color: "bg-[#1A3E5C]/10" },
            { icon: <DollarSign className="w-6 h-6 text-[#C9A227]" />, label: "Fare Records", value: stats.totalFares    || 0, color: "bg-[#C9A227]/10" },
            { icon: <BarChart3 className="w-6 h-6 text-purple-600" />, label: "Journeys",     value: stats.totalJourneys || 0, color: "bg-purple-100" },
          ].map((s, i) => (
            <div key={i} className="bg-white rounded-xl p-5 shadow-sm">
              <div className={`w-10 h-10 ${s.color} rounded-xl flex items-center justify-center mb-3`}>
                {s.icon}
              </div>
              <p className="text-2xl font-bold text-[#1A3E5C]">{s.value.toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Scraper status */}
        <div className="bg-white rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-[#1A3E5C]">Scraper Status</h2>
            <span className="text-xs text-gray-500">Updates every Sunday 2AM (Jamaica)</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-2 px-3 font-semibold text-gray-500">Source</th>
                  <th className="text-left py-2 px-3 font-semibold text-gray-500">Records</th>
                  <th className="text-left py-2 px-3 font-semibold text-gray-500">Last Updated</th>
                  <th className="text-left py-2 px-3 font-semibold text-gray-500">Status</th>
                </tr>
              </thead>
              <tbody>
                {scrapes.length > 0 ? scrapes.map((s: any, i: number) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-2.5 px-3 font-medium text-[#1A3E5C]">{s.source_key}</td>
                    <td className="py-2.5 px-3 text-gray-600">{s.record_count || "—"}</td>
                    <td className="py-2.5 px-3 text-gray-500 text-xs">{s.last_updated ? new Date(s.last_updated).toLocaleString() : "—"}</td>
                    <td className="py-2.5 px-3">
                      <span className="flex items-center gap-1 text-green-600 text-xs">
                        <CheckCircle className="w-3.5 h-3.5" />OK
                      </span>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={4} className="py-6 text-center text-gray-400 text-sm">
                      No scrape data yet. Click "Run Scrape" to fetch latest data.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Popular routes */}
        <div className="bg-white rounded-xl p-5 shadow-sm">
          <h2 className="font-bold text-[#1A3E5C] mb-4">Most Travelled Routes (Last 30 days)</h2>
          {dashboard?.popularRoutes?.length > 0 ? (
            <div className="space-y-2">
              {dashboard.popularRoutes.slice(0, 8).map((r: any, i: number) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50">
                  <span className="text-sm text-[#1A3E5C] font-medium">{r.origin_name} → {r.destination_name}</span>
                  <span className="text-sm text-[#0D7A7A] font-bold">{r.journey_count} journeys</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400 text-center py-4">Journey data will appear here as users plan routes.</p>
          )}
        </div>

        {/* Recent feedback */}
        <div className="bg-white rounded-xl p-5 shadow-sm">
          <h2 className="font-bold text-[#1A3E5C] mb-4">Recent Feedback</h2>
          {dashboard?.recentFeedback?.length > 0 ? (
            <div className="space-y-2">
              {dashboard.recentFeedback.map((f: any, i: number) => (
                <div key={i} className="flex items-center gap-3 py-2 border-b border-gray-50">
                  <AlertCircle className={`w-4 h-4 shrink-0 ${
                    f.report_type === "overcharge" ? "text-red-500" :
                    f.report_type === "unsafe"     ? "text-red-600" : "text-[#C9A227]"
                  }`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-[#1A3E5C]">{f.report_type || "Rating"}</p>
                    <p className="text-xs text-gray-500">{f.notes || "No notes"} · {new Date(f.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    f.status === "resolved" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                  }`}>{f.status}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400 text-center py-4">No feedback received yet.</p>
          )}
        </div>

      </div>
    </div>
  );
}
