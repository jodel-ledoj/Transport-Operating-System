"use client";
import { useEffect, useState } from "react";
import { useRouter }     from "next/navigation";
import { useQuery }      from "@tanstack/react-query";
import { Bus, MapPin, Shield, Clock, ChevronRight,
         Navigation, Star, AlertTriangle, RefreshCw } from "lucide-react";
import { useAuthStore }  from "../../store/authStore";
import { authApi, transitApi } from "../../utils/api";
import Link              from "next/link";

export default function DashboardPage() {
  const router   = useRouter();
  const { user, token, setUser, logout } = useAuthStore();

  // Fetch user profile
  const { data: profile } = useQuery({
    queryKey: ["me"],
    queryFn:  () => authApi.me().then(r => r.data),
    enabled:  !!token,
  });

  // Fetch transit status (last scrape info)
  const { data: transitStatus } = useQuery({
    queryKey: ["transit-status"],
    queryFn:  () => transitApi.status().then(r => r.data),
    enabled:  !!token,
  });

  useEffect(() => {
    if (!token) { router.push("/auth/login"); return; }
    if (profile) setUser(profile);
  }, [token, profile]);

  const quickActions = [
    { icon: <Navigation className="w-6 h-6" />, label: "Plan Route",    href: "/journey",  color: "bg-[#0D7A7A]" },
    { icon: <MapPin     className="w-6 h-6" />, label: "Nearby Stops",  href: "/stops",    color: "bg-[#1A3E5C]" },
    { icon: <Shield     className="w-6 h-6" />, label: "Safety Map",    href: "/safety",   color: "bg-[#C9A227]" },
    { icon: <Bus        className="w-6 h-6" />, label: "All Routes",    href: "/routes",   color: "bg-[#666]"    },
  ];

  const popularRoutes = [
    { from: "Half Way Tree", to: "Downtown Kingston", type: "Bus", fare: "JMD 100" },
    { from: "HWT",           to: "Papine",            type: "Taxi",fare: "JMD 150" },
    { from: "Downtown",      to: "Portmore",          type: "Bus", fare: "JMD 100" },
    { from: "Kingston",      to: "Montego Bay",       type: "Express", fare: "JMD 3,900" },
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Top bar */}
      <header className="bg-[#1A3E5C] text-white px-5 py-4 flex justify-between items-center sticky top-0 z-10 shadow-lg">
        <div className="flex items-center gap-2">
          <Bus className="w-6 h-6 text-[#C9A227]" />
          <span className="font-bold text-lg">TOS Jamaica</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-white/70">Hi, {user?.name?.split(" ")[0] || "Traveller"}</span>
          <button
            onClick={() => { logout(); router.push("/"); }}
            className="text-xs text-white/50 hover:text-white transition px-3 py-1.5 border border-white/20 rounded-lg">
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">

        {/* Search bar */}
        <Link href="/journey"
          className="flex items-center gap-3 bg-white border-2 border-gray-200 rounded-xl p-4 shadow-sm hover:border-[#0D7A7A] transition cursor-pointer group">
          <div className="w-10 h-10 bg-[#0D7A7A] rounded-xl flex items-center justify-center shrink-0">
            <Navigation className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-semibold text-[#1A3E5C]">Where are you going?</p>
            <p className="text-sm text-gray-500">Enter destination to plan your journey</p>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400 ml-auto group-hover:text-[#0D7A7A] transition" />
        </Link>

        {/* Quick actions */}
        <div>
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Quick Actions</h2>
          <div className="grid grid-cols-4 gap-3">
            {quickActions.map((a, i) => (
              <Link key={i} href={a.href}
                className="flex flex-col items-center gap-2 bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition text-center">
                <div className={`w-12 h-12 ${a.color} rounded-xl flex items-center justify-center text-white`}>
                  {a.icon}
                </div>
                <span className="text-xs font-semibold text-[#1A3E5C] leading-tight">{a.label}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Data freshness banner */}
        {transitStatus && (
          <div className="bg-white rounded-xl p-4 shadow-sm flex items-center gap-3 border-l-4 border-[#0D7A7A]">
            <RefreshCw className="w-5 h-5 text-[#0D7A7A] shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-[#1A3E5C]">Data Updated Weekly</p>
              <p className="text-xs text-gray-500">
                {transitStatus.counts?.routes} routes · {transitStatus.counts?.fares} fares · {transitStatus.counts?.stops} stops
              </p>
            </div>
            <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">Live</span>
          </div>
        )}

        {/* Popular routes */}
        <div>
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Popular Routes</h2>
          <div className="space-y-2">
            {popularRoutes.map((r, i) => (
              <Link key={i} href={`/journey?from=${r.from}&to=${r.to}`}
                className="flex items-center gap-3 bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition group">
                <div className="w-10 h-10 bg-[#F5F7FA] rounded-xl flex items-center justify-center shrink-0">
                  <Bus className="w-5 h-5 text-[#0D7A7A]" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-[#1A3E5C] text-sm">{r.from} → {r.to}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      r.type === "Bus"    ? "bg-[#0D7A7A]/10 text-[#0D7A7A]" :
                      r.type === "Taxi"   ? "bg-[#C9A227]/10 text-[#C9A227]" :
                      "bg-[#1A3E5C]/10 text-[#1A3E5C]"
                    }`}>{r.type}</span>
                    <span className="text-xs text-gray-500">{r.fare}</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#0D7A7A] transition" />
              </Link>
            ))}
          </div>
        </div>

        {/* Safety reminder */}
        <div className="bg-[#C9A227]/10 border border-[#C9A227]/30 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#C9A227] shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-[#1A3E5C]">Travel Safe</p>
            <p className="text-xs text-gray-600 mt-0.5">
              Always board at verified taxi stands and JUTC terminals.
              Use the Safety Map before travelling to unfamiliar areas.
            </p>
          </div>
        </div>

        {/* Bottom padding for mobile nav */}
        <div className="h-6" />
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 flex justify-around max-w-2xl mx-auto">
        {[
          { icon: <Bus        className="w-5 h-5" />, label: "Home",    href: "/dashboard" },
          { icon: <Navigation className="w-5 h-5" />, label: "Journey", href: "/journey"  },
          { icon: <MapPin     className="w-5 h-5" />, label: "Stops",   href: "/stops"    },
          { icon: <Shield     className="w-5 h-5" />, label: "Safety",  href: "/safety"   },
        ].map((item, i) => (
          <Link key={i} href={item.href}
            className="flex flex-col items-center gap-1 text-gray-500 hover:text-[#0D7A7A] transition">
            {item.icon}
            <span className="text-xs font-medium">{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
