"use client";
import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { useMutation }     from "@tanstack/react-query";
import { Navigation, MapPin, ArrowLeftRight, Loader2,
         Bus, ChevronRight, Clock, DollarSign,
         ArrowLeft, CheckCircle, AlertCircle } from "lucide-react";
import Link    from "next/link";
import toast   from "react-hot-toast";
import { journeyApi, stopsApi } from "../../utils/api";

interface JourneyLeg {
  stepNumber:   number;
  type:         string;
  instruction:  string;
  fromStop:     string;
  toStop:       string;
  routeNumber:  string;
  operator:     string;
  fareJmd:      number;
  durationMins: number;
  routeColor:   string;
}

interface JourneyOption {
  optionLabel:   string;
  legs:          JourneyLeg[];
  totalFareJmd:  number;
  durationMins:  number;
  transferCount: number;
  safetyRating:  string;
}

// Simple Jamaica location presets
const QUICK_LOCATIONS = [
  { name: "Half Way Tree Transport Centre", lat: 17.9939, lng: -76.7894 },
  { name: "Downtown Kingston Terminal",     lat: 17.9970, lng: -76.7936 },
  { name: "Papine Square",                  lat: 18.0178, lng: -76.7497 },
  { name: "Portmore Bus Terminal",          lat: 17.9503, lng: -76.8839 },
  { name: "Spanish Town Bus Park",          lat: 17.9909, lng: -76.9549 },
  { name: "Constant Spring Square",         lat: 18.0322, lng: -76.7955 },
  { name: "Cross Roads",                    lat: 18.0046, lng: -76.7957 },
  { name: "New Kingston Hub",               lat: 18.0093, lng: -76.7869 },
];

export default function JourneyPage() {
  const searchParams = useSearchParams();
  const [fromName,  setFromName]  = useState(searchParams.get("from") || "");
  const [toName,    setToName]    = useState(searchParams.get("to")   || "");
  const [fromCoord, setFromCoord] = useState<{lat:number;lng:number}|null>(null);
  const [toCoord,   setToCoord]   = useState<{lat:number;lng:number}|null>(null);
  const [options,   setOptions]   = useState<JourneyOption[]>([]);
  const [selected,  setSelected]  = useState<JourneyOption|null>(null);
  const [pref,      setPref]      = useState<"fastest"|"cheapest"|"fewest_transfers">("fastest");
  const [showFromList, setShowFromList] = useState(false);
  const [showToList,   setShowToList]   = useState(false);

  const planMutation = useMutation({
    mutationFn: journeyApi.plan,
    onSuccess: (res) => {
      setOptions(res.data.options || []);
      if (!res.data.options?.length) {
        toast("No direct routes found. Try adjusting your locations.", { icon: "ℹ️" });
      }
    },
    onError: () => toast.error("Failed to plan journey. Please try again."),
  });

  const selectLocation = (which: "from"|"to", loc: typeof QUICK_LOCATIONS[0]) => {
    if (which === "from") {
      setFromName(loc.name);
      setFromCoord({ lat: loc.lat, lng: loc.lng });
      setShowFromList(false);
    } else {
      setToName(loc.name);
      setToCoord({ lat: loc.lat, lng: loc.lng });
      setShowToList(false);
    }
  };

  const handleSwap = () => {
    const tmpName = fromName; setFromName(toName);   setToName(tmpName);
    const tmpCoord = fromCoord; setFromCoord(toCoord); setToCoord(tmpCoord);
  };

  const handlePlan = () => {
    if (!fromCoord || !toCoord) {
      toast.error("Please select both origin and destination.");
      return;
    }
    planMutation.mutate({
      originLat: fromCoord.lat, originLng: fromCoord.lng,
      destLat:   toCoord.lat,   destLng:   toCoord.lng,
      originName: fromName, destName: toName,
      preference: pref,
    });
  };

  const typeIcon = (type: string) => {
    switch (type) {
      case "bus":          return "🚌";
      case "taxi":         return "🚖";
      case "intercity_bus":return "🚍";
      case "walk":         return "🚶";
      default:             return "🚌";
    }
  };

  if (selected) {
    return (
      <div className="min-h-screen bg-[#F5F7FA]">
        <header className="bg-[#1A3E5C] text-white px-5 py-4 flex items-center gap-3 sticky top-0 z-10">
          <button onClick={() => setSelected(null)} className="p-1 hover:bg-white/10 rounded-lg transition">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <p className="font-bold">{fromName} → {toName}</p>
            <p className="text-xs text-white/70">{selected.optionLabel}</p>
          </div>
        </header>

        <div className="max-w-2xl mx-auto p-4 space-y-4">
          {/* Summary card */}
          <div className="bg-[#1A3E5C] text-white rounded-xl p-5 grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-[#C9A227]">JMD {selected.totalFareJmd.toLocaleString()}</p>
              <p className="text-xs text-white/70 mt-1">Total Fare</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{selected.durationMins}<span className="text-base font-normal">min</span></p>
              <p className="text-xs text-white/70 mt-1">Duration</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{selected.transferCount}</p>
              <p className="text-xs text-white/70 mt-1">Transfers</p>
            </div>
          </div>

          {/* Step by step */}
          <div className="bg-white rounded-xl p-5 shadow-sm">
            <h3 className="font-bold text-[#1A3E5C] mb-4">Step-by-Step Directions</h3>
            <div className="space-y-4">
              {selected.legs.map((leg, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-base"
                         style={{ background: leg.routeColor + "22" }}>
                      {typeIcon(leg.type)}
                    </div>
                    {i < selected.legs.length - 1 && (
                      <div className="w-0.5 flex-1 mt-2" style={{ background: leg.routeColor + "44" }} />
                    )}
                  </div>
                  <div className="flex-1 pb-4">
                    <p className="font-semibold text-sm text-[#1C1C1C]">{leg.instruction}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-gray-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />{leg.durationMins} min
                      </span>
                      {leg.fareJmd > 0 && (
                        <span className="text-xs text-[#0D7A7A] font-semibold">
                          JMD {leg.fareJmd.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => toast.success("Journey started! Follow the steps above.")}
            className="w-full py-4 bg-[#0D7A7A] text-white rounded-xl font-bold text-base hover:bg-[#086060] transition flex items-center justify-center gap-2">
            <Navigation className="w-5 h-5" />
            Start Journey
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <header className="bg-[#1A3E5C] text-white px-5 py-4 flex items-center gap-3 sticky top-0 z-10">
        <Link href="/dashboard" className="p-1 hover:bg-white/10 rounded-lg transition">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <p className="font-bold text-lg">Plan Journey</p>
          <p className="text-xs text-white/70">Find the best route</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 space-y-4">

        {/* Origin / Destination inputs */}
        <div className="bg-white rounded-xl shadow-sm overflow-visible">
          <div className="p-4 border-b border-gray-100 relative">
            <label className="text-xs text-gray-500 font-semibold uppercase tracking-wide block mb-1.5">From</label>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#0D7A7A] shrink-0" />
              <input
                value={fromName} onChange={e => { setFromName(e.target.value); setShowFromList(true); }}
                onFocus={() => setShowFromList(true)}
                placeholder="Select origin stop..."
                className="flex-1 outline-none text-sm font-medium text-[#1C1C1C] placeholder-gray-400"
              />
            </div>
            {showFromList && (
              <div className="absolute left-0 right-0 top-full bg-white border border-gray-200 rounded-b-xl shadow-lg z-20 max-h-48 overflow-y-auto">
                {QUICK_LOCATIONS.filter(l => l.name.toLowerCase().includes(fromName.toLowerCase())).map((loc, i) => (
                  <button key={i} onClick={() => selectLocation("from", loc)}
                    className="w-full text-left px-4 py-3 text-sm hover:bg-[#F5F7FA] flex items-center gap-3 border-b border-gray-50">
                    <MapPin className="w-4 h-4 text-[#0D7A7A] shrink-0" />
                    <span className="text-[#1C1C1C]">{loc.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center px-4 py-1">
            <div className="h-6 w-0.5 bg-gray-200 ml-1" />
            <button onClick={handleSwap} className="ml-auto p-2 hover:bg-gray-100 rounded-lg transition">
              <ArrowLeftRight className="w-4 h-4 text-gray-500" />
            </button>
          </div>

          <div className="p-4 relative">
            <label className="text-xs text-gray-500 font-semibold uppercase tracking-wide block mb-1.5">To</label>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#C9A227] shrink-0" />
              <input
                value={toName} onChange={e => { setToName(e.target.value); setShowToList(true); }}
                onFocus={() => setShowToList(true)}
                placeholder="Select destination..."
                className="flex-1 outline-none text-sm font-medium text-[#1C1C1C] placeholder-gray-400"
              />
            </div>
            {showToList && (
              <div className="absolute left-0 right-0 top-full bg-white border border-gray-200 rounded-b-xl shadow-lg z-20 max-h-48 overflow-y-auto">
                {QUICK_LOCATIONS.filter(l => l.name.toLowerCase().includes(toName.toLowerCase())).map((loc, i) => (
                  <button key={i} onClick={() => selectLocation("to", loc)}
                    className="w-full text-left px-4 py-3 text-sm hover:bg-[#F5F7FA] flex items-center gap-3 border-b border-gray-50">
                    <MapPin className="w-4 h-4 text-[#C9A227] shrink-0" />
                    <span className="text-[#1C1C1C]">{loc.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Preference selector */}
        <div className="flex gap-2">
          {(["fastest","cheapest","fewest_transfers"] as const).map(p => (
            <button key={p} onClick={() => setPref(p)}
              className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition ${
                pref === p
                  ? "bg-[#1A3E5C] text-white"
                  : "bg-white text-gray-600 border border-gray-200 hover:border-[#1A3E5C]"
              }`}>
              {p === "fastest" ? "⚡ Fastest" : p === "cheapest" ? "💰 Cheapest" : "🔄 Fewest Stops"}
            </button>
          ))}
        </div>

        {/* Plan button */}
        <button onClick={handlePlan} disabled={planMutation.isPending || !fromCoord || !toCoord}
          className="w-full py-4 bg-[#0D7A7A] text-white rounded-xl font-bold text-base hover:bg-[#086060] transition flex items-center justify-center gap-2 disabled:opacity-60">
          {planMutation.isPending
            ? <><Loader2 className="w-5 h-5 animate-spin" /> Finding Routes...</>
            : <><Navigation className="w-5 h-5" /> Find Routes</>}
        </button>

        {/* Route options */}
        {options.length > 0 && (
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
              {options.length} Route{options.length > 1 ? "s" : ""} Found
            </h3>
            <div className="space-y-3">
              {options.map((opt, i) => (
                <button key={i} onClick={() => setSelected(opt)}
                  className="w-full text-left bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition border-2 border-transparent hover:border-[#0D7A7A] group">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className="text-xs font-bold text-[#0D7A7A] uppercase">{opt.optionLabel}</span>
                      <p className="font-bold text-[#1A3E5C] text-lg">JMD {opt.totalFareJmd.toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-gray-700">{opt.durationMins} min</p>
                      <p className="text-xs text-gray-500">{opt.transferCount} transfer{opt.transferCount !== 1 ? "s" : ""}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {opt.legs.filter(l => l.type !== "walk").map((leg, j) => (
                      <span key={j} className="text-xs px-2.5 py-1 rounded-full font-medium"
                        style={{ background: leg.routeColor + "22", color: leg.routeColor }}>
                        {leg.operator} {leg.routeNumber}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-1 mt-3">
                    <span className={`text-xs font-medium ${
                      opt.safetyRating === "safe"    ? "text-green-600" :
                      opt.safetyRating === "caution" ? "text-[#C9A227]" : "text-gray-400"
                    }`}>
                      {opt.safetyRating === "safe" ? "✅ Safe route" :
                       opt.safetyRating === "caution" ? "⚠️ Use caution" : "Route safety unknown"}
                    </span>
                    <ChevronRight className="w-4 h-4 text-gray-400 ml-auto group-hover:text-[#0D7A7A] transition" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
