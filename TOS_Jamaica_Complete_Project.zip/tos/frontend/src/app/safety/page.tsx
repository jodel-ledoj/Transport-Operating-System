"use client";
import { useQuery } from "@tanstack/react-query";
import { Shield, ArrowLeft, AlertTriangle, CheckCircle, XCircle, Phone } from "lucide-react";
import Link from "next/link";
import { safetyApi } from "../../utils/api";

export default function SafetyPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["safety-zones"],
    queryFn:  () => safetyApi.zones().then(r => r.data),
  });

  const zoneColor = (type: string) => ({
    safe:    { bg: "bg-green-50",      border: "border-green-200",  text: "text-green-700",  icon: <CheckCircle className="w-5 h-5 text-green-600" /> },
    caution: { bg: "bg-yellow-50",     border: "border-yellow-200", text: "text-yellow-700", icon: <AlertTriangle className="w-5 h-5 text-[#C9A227]" /> },
    avoid:   { bg: "bg-red-50",        border: "border-red-200",    text: "text-red-700",    icon: <XCircle className="w-5 h-5 text-red-600" /> },
    unknown: { bg: "bg-gray-50",       border: "border-gray-200",   text: "text-gray-700",   icon: <Shield className="w-5 h-5 text-gray-400" /> },
  }[type] || { bg: "bg-gray-50", border: "border-gray-200", text: "text-gray-700", icon: <Shield className="w-5 h-5 text-gray-400" /> });

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <header className="bg-[#1A3E5C] text-white px-5 py-4 flex items-center gap-3 sticky top-0 z-10">
        <Link href="/dashboard" className="p-1 hover:bg-white/10 rounded-lg transition">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <p className="font-bold text-lg">Safety Map</p>
          <p className="text-xs text-white/70">Transport zone safety ratings</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Legend */}
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <h3 className="font-bold text-[#1A3E5C] mb-3">Zone Guide</h3>
          <div className="space-y-2">
            {[
              { type: "safe",    label: "Safe",    desc: "Well-lit, security presence, high traffic" },
              { type: "caution", label: "Caution", desc: "Extra vigilance advised, especially at night" },
              { type: "avoid",   label: "Avoid",   desc: "Not recommended, use alternative routes" },
            ].map(z => {
              const c = zoneColor(z.type);
              return (
                <div key={z.type} className={`flex items-center gap-3 p-3 rounded-lg ${c.bg} border ${c.border}`}>
                  {c.icon}
                  <div>
                    <p className={`text-sm font-bold ${c.text}`}>{z.label}</p>
                    <p className="text-xs text-gray-500">{z.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Zones list */}
        <div>
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
            Kingston Transport Zones
          </h3>
          {isLoading ? (
            <div className="text-center py-8 text-gray-400">Loading safety data...</div>
          ) : (
            <div className="space-y-2">
              {data?.zones?.map((zone: any, i: number) => {
                const c = zoneColor(zone.zone_type);
                return (
                  <div key={i} className={`bg-white rounded-xl p-4 shadow-sm border-l-4 ${
                    zone.zone_type === "safe"    ? "border-green-500" :
                    zone.zone_type === "caution" ? "border-[#C9A227]" : "border-red-500"
                  }`}>
                    <div className="flex items-center gap-3">
                      {c.icon}
                      <div className="flex-1">
                        <p className="font-semibold text-[#1A3E5C] text-sm">{zone.name}</p>
                        <p className="text-xs text-gray-500 mt-0.5">{zone.description}</p>
                      </div>
                      <span className={`text-xs font-bold px-2 py-1 rounded-full ${c.bg} ${c.text}`}>
                        {zone.zone_type.toUpperCase()}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Emergency */}
        <div className="bg-red-600 text-white rounded-xl p-5 text-center shadow-lg">
          <Shield className="w-8 h-8 mx-auto mb-2" />
          <p className="font-bold text-lg mb-1">Emergency Contact</p>
          <p className="text-sm text-white/80 mb-4">Press and hold 3 seconds to call for help</p>
          <button
            className="w-full py-4 bg-white text-red-600 rounded-xl font-bold text-base flex items-center justify-center gap-2 active:scale-95 transition"
            onContextMenu={(e) => { e.preventDefault(); window.location.href = "tel:119"; }}>
            <Phone className="w-5 h-5" />
            Hold for Emergency (119)
          </button>
        </div>
      </div>
    </div>
  );
}
