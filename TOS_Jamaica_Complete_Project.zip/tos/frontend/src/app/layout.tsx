import type { Metadata } from "next";
import "../styles/globals.css";
import { QueryProvider } from "../components/QueryProvider";
import { Toaster } from "react-hot-toast";

export const metadata: Metadata = {
  title:       "TOS — Jamaica Transport Intelligence",
  description: "Find the best public transport routes across Jamaica. JUTC buses, route taxis, and intercity coaches.",
  keywords:    "Jamaica transport, JUTC, route taxi, bus routes, Kingston transport",
  openGraph: {
    title:       "TOS Jamaica",
    description: "Public transport intelligence for Jamaica",
    type:        "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <QueryProvider>
          {children}
          <Toaster
            position="top-center"
            toastOptions={{
              duration: 4000,
              style: { background: "#1A3E5C", color: "#fff", borderRadius: "8px" },
            }}
          />
        </QueryProvider>
      </body>
    </html>
  );
}
