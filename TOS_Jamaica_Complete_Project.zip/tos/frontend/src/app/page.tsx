"use client";
import Link from "next/link";
import { Bus, MapPin, Shield, Clock, ArrowRight, Star } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#1A3E5C] text-white px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bus className="w-7 h-7 text-[#C9A227]" />
          <span className="text-xl font-bold">TOS Jamaica</span>
        </div>
        <div className="flex gap-3">
          <Link href="/auth/login"
            className="px-4 py-2 text-sm text-white border border-white/30 rounded-lg hover:bg-white/10 transition">
            Log In
          </Link>
          <Link href="/auth/register"
            className="px-4 py-2 text-sm bg-[#C9A227] text-white rounded-lg hover:bg-[#9A7A1E] transition font-semibold">
            Get Started
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-br from-[#1A3E5C] to-[#0D7A7A] text-white px-6 py-20 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-2 text-sm mb-6">
            <Star className="w-4 h-4 text-[#C9A227]" />
            <span>Covering Kingston, St. Andrew & Beyond</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            Know Your Route.<br />
            <span className="text-[#C9A227]">Get There Safe.</span>
          </h1>
          <p className="text-lg text-white/80 mb-8 max-w-xl mx-auto">
            Jamaica's first public transport intelligence platform.
            Find JUTC bus routes, route taxi fares, and multi-leg journeys
            across Kingston — with safety alerts built in.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/register"
              className="inline-flex items-center gap-2 px-8 py-4 bg-[#C9A227] rounded-xl font-bold text-white hover:bg-[#9A7A1E] transition text-lg">
              Plan a Journey <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/dashboard"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white/10 border border-white/30 rounded-xl font-semibold text-white hover:bg-white/20 transition text-lg">
              View Routes Map
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-center text-[#1A3E5C] mb-12">
            Built for Jamaica Commuters
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <MapPin className="w-8 h-8 text-[#0D7A7A]" />,
                title: "Smart Routes",
                desc: "From Half Way Tree to Portmore — we calculate the best path with every transfer.",
              },
              {
                icon: <Clock className="w-8 h-8 text-[#0D7A7A]" />,
                title: "Live Fare Data",
                desc: "Scraped weekly from JUTC, OUR regulated taxi fares, and Knutsford Express.",
              },
              {
                icon: <Shield className="w-8 h-8 text-[#0D7A7A]" />,
                title: "Safety Zones",
                desc: "Color-coded zones for every route. Know before you go.",
              },
              {
                icon: <Bus className="w-8 h-8 text-[#0D7A7A]" />,
                title: "All Transport Types",
                desc: "JUTC buses, route taxis, and Knutsford Express intercity coaches.",
              },
            ].map((f, i) => (
              <div key={i} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition">
                <div className="mb-4">{f.icon}</div>
                <h3 className="font-bold text-[#1A3E5C] mb-2">{f.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Routes preview */}
      <section className="bg-[#F5F7FA] py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-[#1A3E5C] mb-4">Major Routes Covered</h2>
          <p className="text-gray-600 mb-10">Updated weekly by our automated scraper network</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              ["Half Way Tree", "Downtown"],
              ["Papine", "Downtown"],
              ["Portmore", "Kingston"],
              ["Spanish Town", "Kingston"],
              ["Constant Spring", "Half Way Tree"],
              ["Kingston", "Montego Bay"],
            ].map(([from, to], i) => (
              <div key={i}
                className="bg-white rounded-lg p-4 border border-gray-200 flex items-center gap-3 text-sm font-medium text-[#1A3E5C]">
                <MapPin className="w-4 h-4 text-[#0D7A7A] shrink-0" />
                <span>{from} → {to}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-[#1A3E5C] text-white py-16 px-6 text-center">
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl font-bold mb-4">Ready to navigate Jamaica smarter?</h2>
          <p className="text-white/70 mb-8">Register with your Jamaican phone number — it takes 30 seconds.</p>
          <Link href="/auth/register"
            className="inline-flex items-center gap-2 px-10 py-4 bg-[#C9A227] rounded-xl font-bold text-white hover:bg-[#9A7A1E] transition text-lg">
            Create Free Account <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0F2438] text-white/50 text-center py-6 text-sm px-6">
        <p>© 2025 Transport Operating System — Jamaica. Built for the Kingston Hackathon.</p>
        <p className="mt-1 text-xs">Transport data sourced from JUTC, OUR Jamaica, and Knutsford Express.</p>
      </footer>
    </div>
  );
}
