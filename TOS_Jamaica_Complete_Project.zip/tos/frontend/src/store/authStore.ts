import { create } from "zustand";

interface User {
  id:          string;
  name:        string;
  phone:       string;
  email?:      string;
  role:        "user" | "admin";
  preferences: Record<string, any>;
}

interface AuthStore {
  user:         User | null;
  token:        string | null;
  isLoading:    boolean;
  pendingPhone: string;

  setAuth:      (token: string, user: User) => void;
  setUser:      (user: User) => void;
  setPending:   (phone: string) => void;
  logout:       () => void;
  isAdmin:      () => boolean;
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  user:         null,
  token:        typeof window !== "undefined" ? localStorage.getItem("tos_token") : null,
  isLoading:    false,
  pendingPhone: "",

  setAuth: (token, user) => {
    if (typeof window !== "undefined") localStorage.setItem("tos_token", token);
    set({ token, user });
  },

  setUser: (user) => set({ user }),

  setPending: (phone) => set({ pendingPhone: phone }),

  logout: () => {
    if (typeof window !== "undefined") localStorage.removeItem("tos_token");
    set({ user: null, token: null });
  },

  isAdmin: () => get().user?.role === "admin",
}));
