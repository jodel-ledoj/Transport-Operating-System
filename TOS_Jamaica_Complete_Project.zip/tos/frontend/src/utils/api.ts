// ── API Client ─────────────────────────────────────────────────────────────────
import axios from "axios";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
});

// Attach JWT to every request
api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("tos_token");
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  async (err) => {
    if (err.response?.status === 401 && typeof window !== "undefined") {
      localStorage.removeItem("tos_token");
      window.location.href = "/auth/login";
    }
    return Promise.reject(err);
  }
);

// ── API Functions ─────────────────────────────────────────────────────────────

export const authApi = {
  register:  (phone: string, name: string) =>
    api.post("/auth/register", { phone, name }),
  verifyOtp: (phone: string, otp: string) =>
    api.post("/auth/verify-otp", { phone, otp }),
  me:        ()        => api.get("/auth/me"),
  logout:    (token: string) => api.post("/auth/logout", { refreshToken: token }),
  updateProfile: (data: any) => api.patch("/auth/profile", data),
};

export const journeyApi = {
  plan: (params: {
    originLat: number; originLng: number;
    destLat: number; destLng: number;
    originName?: string; destName?: string;
    preference?: "fastest" | "cheapest" | "fewest_transfers";
  }) => api.post("/journey/plan", params),

  history:  ()     => api.get("/journey/history"),
  complete: (id: string) => api.patch(`/journey/${id}/complete`),
};

export const stopsApi = {
  nearby: (lat: number, lng: number, radius = 800) =>
    api.get("/stops/nearby", { params: { lat, lng, radius } }),
  search: (q: string) => api.get("/stops/search", { params: { q } }),
  all:    (parish?: string) => api.get("/stops", { params: { parish } }),
};

export const fareApi = {
  estimate: (from: string, to: string) =>
    api.get("/fare/estimate", { params: { from, to } }),
  lookup: (fromStop: string, toStop: string) =>
    api.get("/transit/fare-lookup", { params: { from_stop: fromStop, to_stop: toStop } }),
};

export const routeApi = {
  search: (from?: string, to?: string) =>
    api.get("/routes/search", { params: { from, to } }),
  all:    (operator?: string) => api.get("/routes", { params: { operator } }),
};

export const safetyApi = {
  zones: () => api.get("/safety/zones"),
  check: (lat: number, lng: number) =>
    api.get("/safety/check", { params: { lat, lng } }),
};

export const feedbackApi = {
  submit: (data: {
    routeId?: string; journeyId?: string;
    rating?: number; reportType?: string; notes?: string;
  }) => api.post("/feedback", data),
  my: () => api.get("/feedback/my"),
};

export const transitApi = {
  status:    () => api.get("/transit/status"),
  fares:     (operator?: string) => api.get("/transit/fares", { params: { operator } }),
  routes:    () => api.get("/transit/routes"),
  schedules: (operator?: string) => api.get("/transit/schedules", { params: { operator } }),
  scrape:    (source?: string) => api.post("/transit/scrape", null, { params: { source } }),
};

export const adminApi = {
  dashboard:  () => api.get("/admin/dashboard"),
  users:      (page = 1) => api.get("/admin/users", { params: { page } }),
  feedback:   (status?: string) => api.get("/admin/feedback", { params: { status } }),
  analytics:  () => api.get("/admin/analytics/routes"),
};
