-- ============================================================
-- TOS Jamaica — Full Database Schema
-- PostgreSQL 15 + PostGIS 3.4
-- ============================================================

-- Enable PostGIS spatial extension
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;  -- for fuzzy text search

-- ── Users ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone           VARCHAR(20) UNIQUE,
    email           VARCHAR(255) UNIQUE,
    name            VARCHAR(100) NOT NULL DEFAULT 'User',
    role            VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
    preferences     JSONB NOT NULL DEFAULT '{}',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ── Sessions / Auth ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token   VARCHAR(512) UNIQUE NOT NULL,
    ip_address      INET,
    user_agent      TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(refresh_token);

-- ── OTP Cache table (supplement Redis) ────────────────────
CREATE TABLE IF NOT EXISTS otp_requests (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone           VARCHAR(20) NOT NULL,
    otp_hash        VARCHAR(64) NOT NULL,
    attempts        INTEGER DEFAULT 0,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Transport Routes ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS routes (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source          VARCHAR(100) NOT NULL DEFAULT 'manual',
    route_number    VARCHAR(20),
    route_name      TEXT NOT NULL,
    origin          TEXT NOT NULL,
    destination     TEXT NOT NULL,
    operator        VARCHAR(100) NOT NULL,
    transport_type  VARCHAR(50) NOT NULL CHECK (transport_type IN ('bus','taxi','charter','intercity_bus')),
    zone            VARCHAR(50),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    first_seen      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_updated    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, route_number, operator)
);

CREATE INDEX IF NOT EXISTS idx_routes_operator ON routes(operator);
CREATE INDEX IF NOT EXISTS idx_routes_type     ON routes(transport_type);
CREATE INDEX IF NOT EXISTS idx_routes_origin   ON routes USING gin(to_tsvector('english', origin));
CREATE INDEX IF NOT EXISTS idx_routes_dest     ON routes USING gin(to_tsvector('english', destination));

-- ── Stops / Terminals ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS stops (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source          VARCHAR(100) NOT NULL DEFAULT 'manual',
    name            TEXT NOT NULL,
    stop_type       VARCHAR(50) NOT NULL DEFAULT 'bus_stop'
                    CHECK (stop_type IN ('bus_stop','terminal','taxi_hub','transfer')),
    operator        VARCHAR(100),
    parish          VARCHAR(100),
    location        GEOGRAPHY(POINT, 4326),  -- PostGIS spatial column
    latitude        NUMERIC(10,7),
    longitude       NUMERIC(10,7),
    routes_served   JSONB NOT NULL DEFAULT '[]',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    first_seen      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_updated    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, name, operator)
);

CREATE INDEX IF NOT EXISTS idx_stops_location  ON stops USING GIST(location);
CREATE INDEX IF NOT EXISTS idx_stops_parish    ON stops(parish);
CREATE INDEX IF NOT EXISTS idx_stops_name      ON stops USING gin(to_tsvector('english', name));

-- ── Fares ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fares (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source          VARCHAR(100) NOT NULL DEFAULT 'manual',
    operator        VARCHAR(100) NOT NULL,
    route           TEXT,
    origin          TEXT,
    destination     TEXT,
    fare_type       VARCHAR(100) NOT NULL DEFAULT 'Standard',
    amount_jmd      NUMERIC(10,2),
    amount_usd      NUMERIC(10,2),
    currency        VARCHAR(10) NOT NULL DEFAULT 'JMD',
    payment_type    VARCHAR(50) DEFAULT 'cash',
    regulated       BOOLEAN DEFAULT FALSE,
    regulator       VARCHAR(100),
    effective_date  DATE,
    is_current      BOOLEAN NOT NULL DEFAULT TRUE,
    first_seen      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_updated    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, operator, COALESCE(route,''), fare_type)
);

CREATE INDEX IF NOT EXISTS idx_fares_operator ON fares(operator);
CREATE INDEX IF NOT EXISTS idx_fares_route    ON fares USING gin(to_tsvector('english', COALESCE(route,'')));

-- ── Schedules ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS schedules (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source          VARCHAR(100) NOT NULL DEFAULT 'manual',
    operator        VARCHAR(100) NOT NULL,
    route           TEXT NOT NULL,
    origin          TEXT,
    destination     TEXT,
    departure_time  VARCHAR(20),
    arrival_time    VARCHAR(20),
    days_of_week    JSONB DEFAULT '["mon","tue","wed","thu","fri","sat","sun"]',
    fare_jmd        NUMERIC(10,2),
    fare_usd        NUMERIC(10,2),
    booking_url     TEXT,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    first_seen      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_updated    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    raw_data        JSONB,
    UNIQUE (source, operator, route, COALESCE(departure_time,''))
);

-- ── Journeys ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS journeys (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
    origin_name     TEXT NOT NULL,
    destination_name TEXT NOT NULL,
    origin_lat      NUMERIC(10,7),
    origin_lng      NUMERIC(10,7),
    dest_lat        NUMERIC(10,7),
    dest_lng        NUMERIC(10,7),
    legs            JSONB NOT NULL DEFAULT '[]',
    total_fare_jmd  NUMERIC(10,2),
    duration_mins   INTEGER,
    status          VARCHAR(30) DEFAULT 'planned'
                    CHECK (status IN ('planned','active','completed','cancelled')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_journeys_user ON journeys(user_id);
CREATE INDEX IF NOT EXISTS idx_journeys_date ON journeys(created_at);

-- ── Safety Zones ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS safety_zones (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            TEXT NOT NULL,
    zone_type       VARCHAR(30) NOT NULL DEFAULT 'caution'
                    CHECK (zone_type IN ('safe','caution','avoid')),
    area            GEOGRAPHY(POLYGON, 4326),
    center_lat      NUMERIC(10,7),
    center_lng      NUMERIC(10,7),
    radius_meters   INTEGER DEFAULT 500,
    description     TEXT,
    active_hours    JSONB DEFAULT '{"all_day": true}',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_safety_zones_area ON safety_zones USING GIST(area);

-- ── Feedback ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
    route_id        UUID REFERENCES routes(id) ON DELETE SET NULL,
    journey_id      UUID REFERENCES journeys(id) ON DELETE SET NULL,
    rating          INTEGER CHECK (rating BETWEEN 1 AND 5),
    report_type     VARCHAR(50) CHECK (report_type IN ('overcharge','unsafe','route_change','delay','other')),
    notes           TEXT,
    status          VARCHAR(30) DEFAULT 'pending'
                    CHECK (status IN ('pending','reviewed','resolved')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_feedback_route ON feedback(route_id);
CREATE INDEX IF NOT EXISTS idx_feedback_user  ON feedback(user_id);

-- ── Activity Logs ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_logs (
    id              BIGSERIAL PRIMARY KEY,
    user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
    action          VARCHAR(100) NOT NULL,
    resource_type   VARCHAR(50),
    resource_id     UUID,
    metadata        JSONB DEFAULT '{}',
    ip_address      INET,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_logs_user    ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_logs_date    ON activity_logs(created_at DESC);

-- ── Scraper Tables (from transit-scraper) ─────────────────
CREATE TABLE IF NOT EXISTS scrape_hashes (
    source_key      VARCHAR(200) PRIMARY KEY,
    content_hash    VARCHAR(64),
    record_count    INTEGER,
    last_updated    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scrape_runs (
    id              SERIAL PRIMARY KEY,
    run_id          VARCHAR(50) NOT NULL,
    source          VARCHAR(100),
    data_type       VARCHAR(50),
    record_count    INTEGER DEFAULT 0,
    changed         BOOLEAN DEFAULT FALSE,
    error           TEXT,
    duration_secs   NUMERIC(8,2),
    scraped_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Saved Locations ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS saved_locations (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label           VARCHAR(50) NOT NULL,  -- 'home', 'work', custom
    name            TEXT NOT NULL,
    latitude        NUMERIC(10,7) NOT NULL,
    longitude       NUMERIC(10,7) NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, label)
);

-- ── Notifications ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type            VARCHAR(50) NOT NULL,
    title           TEXT NOT NULL,
    body            TEXT,
    data            JSONB DEFAULT '{}',
    is_read         BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read);

-- ============================================================
-- Seed Data — Core Kingston Routes
-- ============================================================
INSERT INTO routes (route_number, route_name, origin, destination, operator, transport_type, source) VALUES
('22',  'Half Way Tree – Downtown',       'Half Way Tree',    'Downtown Kingston', 'JUTC', 'bus',   'seed'),
('22A', 'Half Way Tree – Downtown Alt',   'Half Way Tree',    'Downtown Kingston', 'JUTC', 'bus',   'seed'),
('24',  'Papine – Downtown',              'Papine',           'Downtown Kingston', 'JUTC', 'bus',   'seed'),
('38',  'Portmore – Half Way Tree',       'Portmore',         'Half Way Tree',     'JUTC', 'bus',   'seed'),
('45',  'Spanish Town – Downtown',        'Spanish Town',     'Downtown Kingston', 'JUTC', 'bus',   'seed'),
('99',  'Waterford – Half Way Tree',      'Waterford',        'Half Way Tree',     'JUTC', 'bus',   'seed'),
('72',  'Constant Spring – Downtown',     'Constant Spring',  'Downtown Kingston', 'JUTC', 'bus',   'seed'),
('21',  'Barbican – Half Way Tree',       'Barbican',         'Half Way Tree',     'JUTC', 'bus',   'seed'),
('63',  'Havendale – Downtown',           'Havendale',        'Downtown Kingston', 'JUTC', 'bus',   'seed'),
('RT1', 'HWT → Papine',                  'Half Way Tree',    'Papine',            'Route Taxi', 'taxi', 'seed'),
('RT2', 'HWT → New Kingston',            'Half Way Tree',    'New Kingston',      'Route Taxi', 'taxi', 'seed'),
('RT3', 'Downtown → Portmore',           'Downtown Kingston','Portmore',          'Route Taxi', 'taxi', 'seed'),
('RT4', 'HWT → Constant Spring',         'Half Way Tree',    'Constant Spring',   'Route Taxi', 'taxi', 'seed'),
('RT5', 'Cross Roads → Spanish Town',    'Cross Roads',      'Spanish Town',      'Route Taxi', 'taxi', 'seed')
ON CONFLICT (source, route_number, operator) DO NOTHING;

INSERT INTO stops (name, stop_type, operator, parish, latitude, longitude, routes_served, source) VALUES
('Half Way Tree Transport Centre', 'terminal',  'JUTC',       'Kingston',      17.9939, -76.7894, '["22","22A","21","63","99","RT1","RT2","RT4"]', 'seed'),
('Downtown Kingston Terminal',     'terminal',  'JUTC',       'Kingston',      17.9970, -76.7936, '["22","38","45","72","RT3"]',                  'seed'),
('Papine Square',                  'terminal',  'JUTC',       'St. Andrew',    18.0178, -76.7497, '["24","RT1"]',                                 'seed'),
('Spanish Town Bus Park',          'terminal',  'JUTC',       'St. Catherine', 17.9909, -76.9549, '["45","RT5"]',                                 'seed'),
('Portmore Bus Terminal',          'terminal',  'JUTC',       'St. Catherine', 17.9503, -76.8839, '["38","RT3"]',                                 'seed'),
('Constant Spring Square',         'bus_stop',  'JUTC',       'St. Andrew',    18.0322, -76.7955, '["72","RT4"]',                                 'seed'),
('Cross Roads',                    'transfer',  'Multiple',   'Kingston',      18.0046, -76.7957, '["22","24","RT5"]',                            'seed'),
('New Kingston Hub',               'taxi_hub',  'Route Taxi', 'Kingston',      18.0093, -76.7869, '["RT2"]',                                      'seed'),
('Liguanea',                       'taxi_hub',  'Route Taxi', 'St. Andrew',    18.0056, -76.7766, '["RT1"]',                                      'seed'),
('Barbican',                       'bus_stop',  'JUTC',       'St. Andrew',    18.0169, -76.7712, '["21"]',                                       'seed')
ON CONFLICT (source, name, operator) DO NOTHING;

-- Update PostGIS location column from lat/lng
UPDATE stops SET location = ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography
WHERE latitude IS NOT NULL AND longitude IS NOT NULL AND location IS NULL;

INSERT INTO fares (source, operator, route, origin, destination, fare_type, amount_jmd, currency, payment_type, regulated) VALUES
('seed', 'JUTC', 'All Routes',                   NULL, NULL, 'Standard Adult',   100.00, 'JMD', 'cash', false),
('seed', 'JUTC', 'All Routes',                   NULL, NULL, 'Concessionary',     50.00, 'JMD', 'cash', false),
('seed', 'JUTC', 'All Routes',                   NULL, NULL, 'Tap Card Adult',    90.00, 'JMD', 'tap_card', false),
('seed', 'Route Taxi', 'HWT → Downtown Kingston','Half Way Tree', 'Downtown Kingston', 'Standard', 150.00, 'JMD', 'cash', true),
('seed', 'Route Taxi', 'HWT → Papine',           'Half Way Tree', 'Papine',           'Standard', 150.00, 'JMD', 'cash', true),
('seed', 'Route Taxi', 'HWT → New Kingston',     'Half Way Tree', 'New Kingston',     'Standard', 100.00, 'JMD', 'cash', true),
('seed', 'Route Taxi', 'Downtown → Portmore',    'Downtown Kingston', 'Portmore',     'Standard', 300.00, 'JMD', 'cash', true),
('seed', 'Route Taxi', 'Downtown → Spanish Town','Downtown Kingston', 'Spanish Town', 'Standard', 350.00, 'JMD', 'cash', true),
('seed', 'Route Taxi', 'HWT → Constant Spring',  'Half Way Tree', 'Constant Spring', 'Standard', 200.00, 'JMD', 'cash', true),
('seed', 'Knutsford Express', 'KGN-MBJ',         'Kingston', 'Montego Bay', 'Standard', 3900.00, 'JMD', 'booking', false),
('seed', 'Knutsford Express', 'KGN-OCR',         'Kingston', 'Ocho Rios',   'Standard', 2400.00, 'JMD', 'booking', false),
('seed', 'Knutsford Express', 'KGN-MVL',         'Kingston', 'Mandeville',  'Standard', 1900.00, 'JMD', 'booking', false)
ON CONFLICT DO NOTHING;

INSERT INTO safety_zones (name, zone_type, center_lat, center_lng, radius_meters, description) VALUES
('Half Way Tree Commercial',  'safe',    17.9939, -76.7894, 400,  'Major transport hub, well-lit, police presence'),
('Downtown Kingston Terminal','safe',    17.9970, -76.7936, 300,  'JUTC terminal, security personnel'),
('Papine Square',             'caution', 18.0178, -76.7497, 300,  'Busy market area, watch belongings at night'),
('Spanish Town Bus Park',     'caution', 17.9909, -76.9549, 400,  'Extra caution advised after 8PM'),
('Cross Roads',               'safe',    18.0046, -76.7957, 250,  'Well-trafficked intersection, multiple routes')
ON CONFLICT DO NOTHING;
