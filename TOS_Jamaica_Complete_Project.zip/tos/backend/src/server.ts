import Fastify from "fastify";
import fastifyJwt from "@fastify/jwt";
import fastifyCors from "@fastify/cors";
import fastifyHelmet from "@fastify/helmet";
import fastifyRateLimit from "@fastify/rate-limit";
import fastifyRedis from "@fastify/redis";
import { PrismaClient } from "@prisma/client";
import "dotenv/config";

// Route imports
import authRoutes from "./routes/auth";
import routeRoutes from "./routes/routes";
import journeyRoutes from "./routes/journey";
import stopsRoutes from "./routes/stops";
import fareRoutes from "./routes/fares";
import safetyRoutes from "./routes/safety";
import feedbackRoutes from "./routes/feedback";
import transitRoutes from "./routes/transit";   // scraper data bridge
import adminRoutes from "./routes/admin";
import internalRoutes from "./routes/internal";

export const prisma = new PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["query", "error"] : ["error"],
});

async function buildServer() {
  const server = Fastify({
    logger: {
      level: process.env.NODE_ENV === "production" ? "info" : "debug",
      transport: process.env.NODE_ENV !== "production"
        ? { target: "pino-pretty", options: { colorize: true } }
        : undefined,
    },
  });

  // ── Security plugins ──────────────────────────────────────────────────
  await server.register(fastifyHelmet, {
    contentSecurityPolicy: false, // handled by Next.js frontend
  });

  await server.register(fastifyCors, {
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    credentials: true,
  });

  await server.register(fastifyRateLimit, {
    max: 100,
    timeWindow: "1 minute",
    errorResponseBuilder: () => ({
      error: "RATE_LIMIT",
      message: "Too many requests. Please wait before trying again.",
      retryAfter: 60,
    }),
  });

  // ── Auth ──────────────────────────────────────────────────────────────
  await server.register(fastifyJwt, {
    secret: process.env.JWT_SECRET || "dev_secret_change_in_prod_minimum_32_chars",
    sign: { expiresIn: process.env.JWT_EXPIRES_IN || "7d" },
  });

  // ── Redis ─────────────────────────────────────────────────────────────
  await server.register(fastifyRedis, {
    url: process.env.REDIS_URL || "redis://localhost:6379",
  });

  // ── Decorators ───────────────────────────────────────────────────────
  server.decorate("prisma", prisma);

  // Auth middleware decorator
  server.decorate("authenticate", async (request: any, reply: any) => {
    try {
      await request.jwtVerify();
    } catch (err) {
      reply.code(401).send({
        error: "UNAUTHORIZED",
        message: "Invalid or expired token. Please log in again.",
      });
    }
  });

  server.decorate("requireAdmin", async (request: any, reply: any) => {
    try {
      await request.jwtVerify();
      if (request.user.role !== "admin") {
        reply.code(403).send({ error: "FORBIDDEN", message: "Admin access required." });
      }
    } catch (err) {
      reply.code(401).send({ error: "UNAUTHORIZED", message: "Authentication required." });
    }
  });

  // ── Health check ─────────────────────────────────────────────────────
  server.get("/health", async () => ({
    status: "ok",
    service: "TOS Backend",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
  }));

  // ── Routes ───────────────────────────────────────────────────────────
  await server.register(authRoutes,     { prefix: "/api/auth" });
  await server.register(routeRoutes,    { prefix: "/api/routes" });
  await server.register(journeyRoutes,  { prefix: "/api/journey" });
  await server.register(stopsRoutes,    { prefix: "/api/stops" });
  await server.register(fareRoutes,     { prefix: "/api/fare" });
  await server.register(safetyRoutes,   { prefix: "/api/safety" });
  await server.register(feedbackRoutes, { prefix: "/api/feedback" });
  await server.register(transitRoutes,  { prefix: "/api/transit" });   // scraper bridge
  await server.register(adminRoutes,    { prefix: "/api/admin" });
  await server.register(internalRoutes, { prefix: "/internal" });

  // ── Global error handler ─────────────────────────────────────────────
  server.setErrorHandler((error, request, reply) => {
    server.log.error(error);

    if (error.validation) {
      return reply.code(400).send({
        error: "VALIDATION_ERROR",
        message: "Invalid request data.",
        fields: error.validation,
      });
    }

    if (error.statusCode === 429) {
      return reply.code(429).send({
        error: "RATE_LIMIT",
        message: "Too many requests.",
        retryAfter: 60,
      });
    }

    reply.code(error.statusCode || 500).send({
      error: error.statusCode ? "REQUEST_ERROR" : "INTERNAL_ERROR",
      message: error.message || "An unexpected error occurred.",
      requestId: request.id,
    });
  });

  return server;
}

async function main() {
  const server = await buildServer();

  try {
    await prisma.$connect();
    server.log.info("✅ Database connected");

    const port = parseInt(process.env.PORT || "4000");
    await server.listen({ port, host: "0.0.0.0" });
    server.log.info(`🚀 TOS Backend running on port ${port}`);
  } catch (err) {
    server.log.error(err);
    await prisma.$disconnect();
    process.exit(1);
  }

  // Graceful shutdown
  const shutdown = async () => {
    await server.close();
    await prisma.$disconnect();
    process.exit(0);
  };

  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

main();
