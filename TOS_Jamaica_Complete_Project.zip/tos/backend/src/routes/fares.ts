import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../server";

export default async function fareRoutes(server: FastifyInstance) {
  // GET /api/fare/estimate?from=&to=
  server.get("/estimate", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { from: fromStop, to: toStop } = request.query as any;
    if (!fromStop || !toStop) {
      return reply.code(400).send({ error: "from and to parameters required" });
    }

    // Direct fare lookup
    let fares = await prisma.fares.findMany({
      where: {
        is_current: true,
        OR: [
          {
            origin:      { contains: fromStop, mode: "insensitive" },
            destination: { contains: toStop,   mode: "insensitive" },
          },
          { origin: null, destination: null }, // flat-fare routes
        ],
      },
      orderBy: { amount_jmd: "asc" },
    });

    const options = fares.map(f => ({
      operator:    f.operator,
      fareType:    f.fare_type,
      amountJmd:   parseFloat(f.amount_jmd as any) || 0,
      paymentType: f.payment_type,
      regulated:   f.regulated,
    }));

    reply.send({
      from:       fromStop,
      to:         toStop,
      currency:   "JMD",
      cheapest:   options[0]?.amountJmd || null,
      options,
      lastUpdated: new Date().toISOString(),
    });
  });

  // GET /api/fare/all
  server.get("/all", async (request: FastifyRequest, reply: FastifyReply) => {
    const { operator } = request.query as any;
    const where: any = { is_current: true };
    if (operator) where.operator = { contains: operator, mode: "insensitive" };

    const fares = await prisma.fares.findMany({
      where,
      orderBy: [{ operator: "asc" }, { amount_jmd: "asc" }],
    });
    reply.send({ count: fares.length, fares });
  });
}
