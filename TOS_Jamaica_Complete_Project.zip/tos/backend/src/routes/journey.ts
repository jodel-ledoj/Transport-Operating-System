import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { z } from "zod";
import { prisma } from "../server";
import { planJourney, type JourneyLeg } from "../services/routeEngine";

const PlanSchema = z.object({
  originLat:    z.number().min(17.5).max(18.5),  // Jamaica bounds
  originLng:    z.number().min(-78.5).max(-76.0),
  destLat:      z.number().min(17.5).max(18.5),
  destLng:      z.number().min(-78.5).max(-76.0),
  originName:   z.string().optional(),
  destName:     z.string().optional(),
  preference:   z.enum(["fastest", "cheapest", "fewest_transfers"]).default("fastest"),
});

export default async function journeyRoutes(server: FastifyInstance) {

  // POST /api/journey/plan
  server.post("/plan", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const body = PlanSchema.parse(request.body);
    const user = request.user as any;

    // Find nearby stops to origin and destination via PostGIS
    const [originStops, destStops] = await Promise.all([
      findNearbyStops(body.originLat, body.originLng, 800),
      findNearbyStops(body.destLat, body.destLng, 800),
    ]);

    if (!originStops.length || !destStops.length) {
      return reply.code(200).send({
        journeyId: null,
        options:   [],
        message:   "No transport stops found nearby. Try a broader area or check your location.",
      });
    }

    // Run route planning engine
    const options = await planJourney({
      originStops,
      destStops,
      originName: body.originName || "Your Location",
      destName:   body.destName   || "Destination",
      preference: body.preference,
    });

    // Save journey record
    const journey = await prisma.journeys.create({
      data: {
        user_id:          user.userId,
        origin_name:      body.originName  || "Your Location",
        destination_name: body.destName    || "Destination",
        origin_lat:       body.originLat,
        origin_lng:       body.originLng,
        dest_lat:         body.destLat,
        dest_lng:         body.destLng,
        legs:             options[0]?.legs || [],
        total_fare_jmd:   options[0]?.totalFareJmd || 0,
        duration_mins:    options[0]?.durationMins || 0,
        status:           "planned",
      },
    });

    reply.send({
      journeyId: journey.id,
      options,
      nearbyStops: {
        origin:      originStops.slice(0, 3),
        destination: destStops.slice(0, 3),
      },
    });
  });

  // GET /api/journey/:id
  server.get("/:id", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as any;
    const user   = request.user as any;

    const journey = await prisma.journeys.findFirst({
      where: { id, user_id: user.userId },
    });

    if (!journey) return reply.code(404).send({ error: "NOT_FOUND" });
    reply.send(journey);
  });

  // GET /api/journey/history
  server.get("/history", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const user = request.user as any;
    const journeys = await prisma.journeys.findMany({
      where:   { user_id: user.userId },
      orderBy: { created_at: "desc" },
      take:    20,
    });
    reply.send({ journeys });
  });

  // PATCH /api/journey/:id/complete
  server.patch("/:id/complete", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as any;
    const user   = request.user as any;

    await prisma.journeys.updateMany({
      where: { id, user_id: user.userId },
      data:  { status: "completed", completed_at: new Date() },
    });
    reply.send({ message: "Journey marked as completed." });
  });
}

async function findNearbyStops(lat: number, lng: number, radiusMeters: number) {
  // PostGIS spatial query
  const stops = await prisma.$queryRaw<any[]>`
    SELECT id, name, stop_type, operator, parish, latitude, longitude,
           routes_served,
           ST_Distance(
             location,
             ST_SetSRID(ST_MakePoint(${lng}, ${lat}), 4326)::geography
           ) AS distance_meters
    FROM stops
    WHERE is_active = true
      AND ST_DWithin(
        location,
        ST_SetSRID(ST_MakePoint(${lng}, ${lat}), 4326)::geography,
        ${radiusMeters}
      )
    ORDER BY distance_meters ASC
    LIMIT 5
  `;
  return stops;
}
