/**
 * Transit Data API — Scraper Bridge
 * ─────────────────────────────────────────────────────────
 * Exposes the transit-scraper PostgreSQL tables via REST.
 * These are populated weekly by the Python scraper service.
 * Mirrors the scraper's own API but unified in the main backend.
 */
import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../server";
import * as fs from "fs";
import * as path from "path";

export default async function transitRoutes(server: FastifyInstance) {

  // GET /api/transit/fares — all scraped fares (filterable)
  server.get("/fares", async (request: FastifyRequest, reply: FastifyReply) => {
    const { operator, origin, destination } = request.query as any;

    const where: any = { is_current: true };
    if (operator)    where.operator    = { contains: operator,    mode: "insensitive" };
    if (origin)      where.origin      = { contains: origin,      mode: "insensitive" };
    if (destination) where.destination = { contains: destination, mode: "insensitive" };

    const fares = await prisma.fares.findMany({
      where,
      orderBy: [{ operator: "asc" }, { amount_jmd: "asc" }],
    });

    reply.send({ count: fares.length, fares });
  });

  // GET /api/transit/routes
  server.get("/routes", async (request: FastifyRequest, reply: FastifyReply) => {
    const { operator } = request.query as any;
    const where: any = { is_active: true };
    if (operator) where.operator = { contains: operator, mode: "insensitive" };

    const routes = await prisma.routes.findMany({
      where,
      orderBy: [{ operator: "asc" }, { route_number: "asc" }],
    });
    reply.send({ count: routes.length, routes });
  });

  // GET /api/transit/stops
  server.get("/stops", async (request: FastifyRequest, reply: FastifyReply) => {
    const { parish } = request.query as any;
    const where: any = { is_active: true };
    if (parish) where.parish = { contains: parish, mode: "insensitive" };

    const stops = await prisma.stops.findMany({ where, orderBy: [{ parish: "asc" }, { name: "asc" }] });
    reply.send({ count: stops.length, stops });
  });

  // GET /api/transit/schedules
  server.get("/schedules", async (request: FastifyRequest, reply: FastifyReply) => {
    const { operator, route } = request.query as any;
    const where: any = { is_active: true };
    if (operator) where.operator = { contains: operator, mode: "insensitive" };
    if (route)    where.route    = { contains: route,    mode: "insensitive" };

    const schedules = await prisma.schedules.findMany({
      where,
      orderBy: [{ operator: "asc" }, { departure_time: "asc" }],
    });
    reply.send({ count: schedules.length, schedules });
  });

  // GET /api/transit/fare-lookup?from_stop=&to_stop=
  server.get("/fare-lookup", async (request: FastifyRequest, reply: FastifyReply) => {
    const { from_stop, to_stop } = request.query as any;
    if (!from_stop || !to_stop) {
      return reply.code(400).send({ error: "from_stop and to_stop required" });
    }

    let fares = await prisma.fares.findMany({
      where: {
        is_current:  true,
        origin:      { contains: from_stop, mode: "insensitive" },
        destination: { contains: to_stop,   mode: "insensitive" },
      },
      orderBy: { amount_jmd: "asc" },
    });

    if (!fares.length) {
      // Reverse direction
      fares = await prisma.fares.findMany({
        where: {
          is_current:  true,
          origin:      { contains: to_stop,   mode: "insensitive" },
          destination: { contains: from_stop, mode: "insensitive" },
        },
        orderBy: { amount_jmd: "asc" },
      });
    }

    if (!fares.length) {
      return reply.send({
        from:    from_stop,
        to:      to_stop,
        options: [],
        message: "No direct fare found. A transfer may be needed.",
      });
    }

    const sorted = fares.sort((a: any, b: any) =>
      (parseFloat(a.amount_jmd) || 9999) - (parseFloat(b.amount_jmd) || 9999)
    );

    reply.send({
      from:         from_stop,
      to:           to_stop,
      cheapest_jmd: parseFloat(sorted[0].amount_jmd as any),
      options:      sorted,
    });
  });

  // GET /api/transit/status — last scrape run
  server.get("/status", async (_request, reply) => {
    const latestPath = path.join("/app/data/snapshots", "latest.json");

    // Check DB for latest scrape hash
    const hashes = await prisma.scrape_hashes.findMany({
      orderBy: { last_updated: "desc" },
      take: 10,
    });

    let snapshotData: any = null;
    if (fs.existsSync(latestPath)) {
      try {
        snapshotData = JSON.parse(fs.readFileSync(latestPath, "utf8"));
      } catch {}
    }

    reply.send({
      status:    "ok",
      scrapers:  hashes,
      lastRun:   snapshotData?.report || null,
      snapshot:  snapshotData?.run_id || null,
      counts: {
        routes:    await prisma.routes.count({ where: { is_active: true } }),
        stops:     await prisma.stops.count({ where: { is_active: true } }),
        fares:     await prisma.fares.count({ where: { is_current: true } }),
        schedules: await prisma.schedules.count({ where: { is_active: true } }),
      },
    });
  });

  // POST /api/transit/scrape — trigger manual scrape (admin only)
  server.post("/scrape", {
    preHandler: [server.requireAdmin],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { source } = request.query as any;

    // Signal the Python scraper service via webhook
    // The scraper container watches for this file
    const triggerPath = path.join("/app/data", "scrape_trigger.json");
    fs.writeFileSync(triggerPath, JSON.stringify({
      triggered_at: new Date().toISOString(),
      source:       source || "all",
      triggered_by: "admin_api",
    }));

    reply.send({
      message: `Scrape triggered${source ? " for " + source : " (all sources)"}. Check /api/transit/status for results.`,
      status:  "queued",
    });
  });
}
