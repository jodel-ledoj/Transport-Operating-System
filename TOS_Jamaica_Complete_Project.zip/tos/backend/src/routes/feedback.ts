import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { z } from "zod";
import { prisma } from "../server";

const FeedbackSchema = z.object({
  routeId:    z.string().uuid().optional(),
  journeyId:  z.string().uuid().optional(),
  rating:     z.number().int().min(1).max(5).optional(),
  reportType: z.enum(["overcharge","unsafe","route_change","delay","other"]).optional(),
  notes:      z.string().max(500).optional(),
});

export default async function feedbackRoutes(server: FastifyInstance) {
  // POST /api/feedback
  server.post("/", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const body = FeedbackSchema.parse(request.body);
    const user = request.user as any;

    const feedback = await prisma.feedback.create({
      data: {
        user_id:     user.userId,
        route_id:    body.routeId   || null,
        journey_id:  body.journeyId || null,
        rating:      body.rating    || null,
        report_type: body.reportType || null,
        notes:       body.notes     || null,
        status:      "pending",
      },
    });

    reply.code(201).send({
      feedbackId: feedback.id,
      status:     "received",
      message:    "Thank you for your feedback. It helps improve TOS for everyone.",
    });
  });

  // GET /api/feedback/my  — user's own feedback
  server.get("/my", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const user = request.user as any;
    const items = await prisma.feedback.findMany({
      where:   { user_id: user.userId },
      orderBy: { created_at: "desc" },
      take:    20,
    });
    reply.send({ feedback: items });
  });
}
