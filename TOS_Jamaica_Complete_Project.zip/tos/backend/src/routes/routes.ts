import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../server";

// ============================================================
// ROUTES  — GET /api/routes
// ============================================================
export default async function routeRoutes(server: FastifyInstance) {
  server.get("/search", async (request: FastifyRequest, reply: FastifyReply) => {
    const { from, to, type } = request.query as any;

    const where: any = { is_active: true };
    if (type) where.transport_type = type;

    if (from && to) {
      where.OR = [
        {
          origin:      { contains: from, mode: "insensitive" },
          destination: { contains: to,   mode: "insensitive" },
        },
        {
          origin:      { contains: to,   mode: "insensitive" },
          destination: { contains: from, mode: "insensitive" },
        },
      ];
    } else if (from) {
      where.OR = [
        { origin:      { contains: from, mode: "insensitive" } },
        { destination: { contains: from, mode: "insensitive" } },
      ];
    }

    const routes = await prisma.routes.findMany({
      where,
      orderBy: [{ operator: "asc" }, { route_number: "asc" }],
      take: 20,
    });

    reply.send({ count: routes.length, routes });
  });

  server.get("/:id", async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as any;
    const route  = await prisma.routes.findUnique({ where: { id } });
    if (!route) return reply.code(404).send({ error: "NOT_FOUND" });
    reply.send(route);
  });

  server.get("/", async (request: FastifyRequest, reply: FastifyReply) => {
    const { operator, type } = request.query as any;
    const where: any = { is_active: true };
    if (operator) where.operator = { contains: operator, mode: "insensitive" };
    if (type)     where.transport_type = type;

    const routes = await prisma.routes.findMany({
      where,
      orderBy: [{ operator: "asc" }, { route_number: "asc" }],
    });
    reply.send({ count: routes.length, routes });
  });
}
