import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../server";

// ============================================================
// ADMIN ROUTES  — /api/admin  (admin role required)
// ============================================================
export default async function adminRoutes(server: FastifyInstance) {

  // GET /api/admin/dashboard
  server.get("/dashboard", {
    preHandler: [server.requireAdmin],
  }, async (_req, reply) => {
    const [
      totalUsers, totalJourneys, totalRoutes, totalFares,
      recentFeedback, recentScrapes
    ] = await Promise.all([
      prisma.users.count(),
      prisma.journeys.count(),
      prisma.routes.count({ where: { is_active: true } }),
      prisma.fares.count({ where: { is_current: true } }),
      prisma.feedback.findMany({ orderBy: { created_at: "desc" }, take: 10 }),
      prisma.scrape_hashes.findMany({ orderBy: { last_updated: "desc" }, take: 6 }),
    ]);

    // Popular routes from journey data
    const popularRoutes = await prisma.$queryRaw<any[]>`
      SELECT origin_name, destination_name, COUNT(*) as journey_count
      FROM journeys
      GROUP BY origin_name, destination_name
      ORDER BY journey_count DESC
      LIMIT 10
    `;

    reply.send({
      stats: { totalUsers, totalJourneys, totalRoutes, totalFares },
      recentFeedback,
      recentScrapes,
      popularRoutes,
    });
  });

  // GET /api/admin/users
  server.get("/users", {
    preHandler: [server.requireAdmin],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { page = 1, limit = 50 } = request.query as any;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [users, total] = await Promise.all([
      prisma.users.findMany({
        skip,
        take: parseInt(limit),
        orderBy: { created_at: "desc" },
        select: { id: true, name: true, phone: true, email: true, role: true, is_active: true, created_at: true },
      }),
      prisma.users.count(),
    ]);

    reply.send({ users, total, page: parseInt(page), limit: parseInt(limit) });
  });

  // GET /api/admin/feedback
  server.get("/feedback", {
    preHandler: [server.requireAdmin],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { status } = request.query as any;
    const where: any = {};
    if (status) where.status = status;

    const feedback = await prisma.feedback.findMany({
      where,
      orderBy: { created_at: "desc" },
      take: 100,
    });
    reply.send({ count: feedback.length, feedback });
  });

  // PATCH /api/admin/feedback/:id
  server.patch("/feedback/:id", {
    preHandler: [server.requireAdmin],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { id }     = request.params as any;
    const { status } = request.body   as any;

    await prisma.feedback.update({
      where: { id },
      data:  { status },
    });
    reply.send({ message: "Feedback status updated." });
  });

  // GET /api/admin/analytics/routes
  server.get("/analytics/routes", {
    preHandler: [server.requireAdmin],
  }, async (_req, reply) => {
    const popularOrigins = await prisma.$queryRaw<any[]>`
      SELECT origin_name, COUNT(*) as count
      FROM journeys WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY origin_name ORDER BY count DESC LIMIT 10
    `;

    const popularDestinations = await prisma.$queryRaw<any[]>`
      SELECT destination_name, COUNT(*) as count
      FROM journeys WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY destination_name ORDER BY count DESC LIMIT 10
    `;

    const dailyJourneys = await prisma.$queryRaw<any[]>`
      SELECT DATE(created_at) as date, COUNT(*) as count
      FROM journeys WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY date ORDER BY date DESC
    `;

    reply.send({ popularOrigins, popularDestinations, dailyJourneys });
  });
}
