import { FastifyInstance } from "fastify";
import { prisma } from "../server";

export default async function internalRoutes(server: FastifyInstance) {
  // POST /internal/scrape-complete — called by Python scraper when done
  server.post("/scrape-complete", async (request, reply) => {
    const body = request.body as any;
    server.log.info({ scrapeReport: body }, "Scraper completed a run");

    // Log the run to DB
    if (body?.run_id) {
      await prisma.scrape_runs.createMany({
        data: (body.changed_sources || []).map((source: string) => ({
          run_id:    body.run_id,
          source:    source.split(":")[0],
          data_type: source.split(":")[1],
          changed:   true,
        })),
        skipDuplicates: true,
      });
    }

    reply.send({ received: true });
  });
}
