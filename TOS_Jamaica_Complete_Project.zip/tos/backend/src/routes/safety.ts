import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../server";

// ============================================================
// SAFETY ROUTES  — GET /api/safety
// ============================================================
export async function safetyRoutes(server: FastifyInstance) {
  // GET /api/safety/zones
  server.get("/zones", async (request: FastifyRequest, reply: FastifyReply) => {
    const zones = await prisma.safety_zones.findMany({
      where: { is_active: true },
      orderBy: { zone_type: "asc" },
    });
    reply.send({ count: zones.length, zones });
  });

  // GET /api/safety/check?lat=&lng=
  server.get("/check", async (request: FastifyRequest, reply: FastifyReply) => {
    const { lat, lng } = request.query as any;
    if (!lat || !lng) return reply.code(400).send({ error: "lat and lng required" });

    const zones = await prisma.$queryRaw<any[]>`
      SELECT name, zone_type, description, radius_meters
      FROM safety_zones
      WHERE is_active = true
        AND ST_DWithin(
          ST_SetSRID(ST_MakePoint(${parseFloat(lng)}, ${parseFloat(lat)}), 4326)::geography,
          ST_SetSRID(ST_MakePoint(center_lng::float8, center_lat::float8), 4326)::geography,
          radius_meters
        )
      ORDER BY zone_type ASC
      LIMIT 5
    `;

    const rating = zones.length === 0 ? "unknown"
                 : zones.some(z => z.zone_type === "avoid")   ? "avoid"
                 : zones.some(z => z.zone_type === "caution") ? "caution"
                 : "safe";

    reply.send({ lat, lng, rating, zones });
  });
}

export default safetyRoutes;
