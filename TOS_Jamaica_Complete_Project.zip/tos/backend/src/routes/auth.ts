import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../server";
import { generateOTP, hashOTP, sendOTPViaSMS } from "../services/otpService";

// ── Validators ────────────────────────────────────────────
const RegisterSchema = z.object({
  phone: z.string().min(7).max(15).regex(/^\+?[0-9]+$/),
  name:  z.string().min(2).max(100),
});

const VerifyOTPSchema = z.object({
  phone: z.string(),
  otp:   z.string().length(6),
});

const LoginSchema = z.object({
  phone:    z.string().optional(),
  email:    z.string().email().optional(),
  password: z.string().min(6).optional(),
});

// ── Routes ───────────────────────────────────────────────
export default async function authRoutes(server: FastifyInstance) {

  // POST /api/auth/register
  server.post("/register", async (request: FastifyRequest, reply: FastifyReply) => {
    const body = RegisterSchema.parse(request.body);

    // Normalize phone
    const phone = body.phone.startsWith("+") ? body.phone : `+1876${body.phone.replace(/^0/, "")}`;

    // Check if user exists
    const existing = await prisma.users.findUnique({ where: { phone } });

    if (!existing) {
      await prisma.users.create({
        data: { phone, name: body.name },
      });
    }

    // Generate + send OTP
    const otp = generateOTP();
    const otpHash = await hashOTP(otp);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store OTP hash in Redis (with 10 min TTL)
    await server.redis.setex(`otp:${phone}`, 600, otpHash);
    await server.redis.setex(`otp_attempts:${phone}`, 600, "0");

    // Send OTP via Twilio (or log in dev)
    await sendOTPViaSMS(phone, otp);

    reply.code(200).send({
      message: "OTP sent to your phone number.",
      phone: phone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"), // mask
    });
  });

  // POST /api/auth/verify-otp
  server.post("/verify-otp", async (request: FastifyRequest, reply: FastifyReply) => {
    const body = VerifyOTPSchema.parse(request.body);
    const phone = body.phone;

    // Check attempt count
    const attemptsKey = `otp_attempts:${phone}`;
    const attempts = parseInt((await server.redis.get(attemptsKey)) || "0");
    if (attempts >= 3) {
      return reply.code(429).send({
        error: "TOO_MANY_ATTEMPTS",
        message: "Too many failed attempts. Wait 10 minutes and request a new code.",
      });
    }

    // Get stored hash
    const storedHash = await server.redis.get(`otp:${phone}`);
    if (!storedHash) {
      return reply.code(400).send({
        error: "OTP_EXPIRED",
        message: "OTP has expired. Please request a new one.",
      });
    }

    // Verify OTP
    const valid = await bcrypt.compare(body.otp, storedHash);
    if (!valid) {
      await server.redis.incr(attemptsKey);
      return reply.code(400).send({
        error: "INVALID_OTP",
        message: "Incorrect verification code. Please try again.",
      });
    }

    // OTP valid — clear from Redis
    await server.redis.del(`otp:${phone}`);
    await server.redis.del(attemptsKey);

    // Get or create user
    let user = await prisma.users.findUnique({ where: { phone } });
    if (!user) {
      user = await prisma.users.create({ data: { phone, name: "User" } });
    }

    // Issue JWT
    const token = server.jwt.sign({
      userId: user.id,
      role:   user.role,
      phone:  user.phone,
    });

    // Issue refresh token
    const refreshToken = server.jwt.sign({ userId: user.id }, { expiresIn: "30d" });
    await prisma.sessions.create({
      data: {
        user_id:       user.id,
        refresh_token: refreshToken,
        ip_address:    request.ip,
        user_agent:    request.headers["user-agent"],
        expires_at:    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    });

    reply.code(200).send({
      token,
      refreshToken,
      user: {
        id:    user.id,
        name:  user.name,
        phone: user.phone,
        role:  user.role,
      },
    });
  });

  // POST /api/auth/refresh
  server.post("/refresh", async (request: FastifyRequest, reply: FastifyReply) => {
    const { refreshToken } = request.body as any;
    if (!refreshToken) return reply.code(400).send({ error: "MISSING_TOKEN" });

    const session = await prisma.sessions.findUnique({
      where: { refresh_token: refreshToken },
      include: { users: true },
    });

    if (!session || session.expires_at < new Date()) {
      return reply.code(401).send({ error: "INVALID_REFRESH_TOKEN" });
    }

    const newToken = server.jwt.sign({
      userId: session.users.id,
      role:   session.users.role,
      phone:  session.users.phone,
    });

    reply.send({ token: newToken });
  });

  // POST /api/auth/logout
  server.post("/logout", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const { refreshToken } = request.body as any;
    if (refreshToken) {
      await prisma.sessions.deleteMany({ where: { refresh_token: refreshToken } });
    }
    reply.send({ message: "Logged out successfully." });
  });

  // GET /api/auth/me
  server.get("/me", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const user = request.user as any;
    const profile = await prisma.users.findUnique({
      where: { id: user.userId },
      include: { saved_locations: true },
    });

    if (!profile) return reply.code(404).send({ error: "USER_NOT_FOUND" });

    reply.send({
      id:              profile.id,
      name:            profile.name,
      phone:           profile.phone,
      email:           profile.email,
      role:            profile.role,
      preferences:     profile.preferences,
      savedLocations:  profile.saved_locations,
    });
  });

  // PATCH /api/auth/profile
  server.patch("/profile", {
    preHandler: [server.authenticate],
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const user = request.user as any;
    const body = request.body as any;

    const updated = await prisma.users.update({
      where: { id: user.userId },
      data: {
        name:        body.name        || undefined,
        email:       body.email       || undefined,
        preferences: body.preferences || undefined,
        updated_at:  new Date(),
      },
    });

    reply.send({ message: "Profile updated.", user: updated });
  });
}
