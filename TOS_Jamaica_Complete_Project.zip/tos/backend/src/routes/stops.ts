// ── stops.ts ─────────────────────────────────────────────────────────────────
import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../server";

export async function stopsRoutes(server: FastifyInstance) {
  // GET /api/stops/nearby?lat=&lng=&radius=
  server.get("/nearby", async (request: FastifyRequest, reply: FastifyReply) => {
    const { lat, lng, radius = 800 } = request.query as any;

    if (!lat || !lng) {
      return reply.code(400).send({ error: "lat and lng are required" });
    }

    const stops = await prisma.$queryRaw<any[]>`
      SELECT id, name, stop_type, operator, parish, latitude, longitude,
             routes_served,
             ST_Distance(
               location,
               ST_SetSRID(ST_MakePoint(${parseFloat(lng)}, ${parseFloat(lat)}), 4326)::geography
             )::integer AS distance_meters
      FROM stops
      WHERE is_active = true
        AND ST_DWithin(
          location,
          ST_SetSRID(ST_MakePoint(${parseFloat(lng)}, ${parseFloat(lat)}), 4326)::geography,
          ${parseInt(radius as string)}
        )
      ORDER BY distance_meters ASC
      LIMIT 10
    `;

    reply.send({ count: stops.length, stops });
  });

  // GET /api/stops/search?q=
  server.get("/search", async (request: FastifyRequest, reply: FastifyReply) => {
    const { q } = request.query as any;
    if (!q || q.length < 2) return reply.send({ stops: [] });

    const stops = await prisma.$queryRaw<any[]>`
      SELECT id, name, stop_type, operator, parish, latitude, longitude
      FROM stops
      WHERE is_active = true
        AND (name ILIKE ${"%" + q + "%"} OR parish ILIKE ${"%" + q + "%"})
      ORDER BY name ASC
      LIMIT 10
    `;
    reply.send({ stops });
  });

  // GET /api/stops
  server.get("/", async (request: FastifyRequest, reply: FastifyReply) => {
    const { parish, type } = request.query as any;
    const where: any = { is_active: true };
    if (parish) where.parish = { contains: parish, mode: "insensitive" };
    if (type)   where.stop_type = type;

    const stops = await prisma.stops.findMany({
      where,
      orderBy: [{ parish: "asc" }, { name: "asc" }],
    });
    reply.send({ count: stops.length, stops });
  });
}

export default stopsRoutes;
