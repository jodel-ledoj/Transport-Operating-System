/**
 * TOS Route Planning Engine
 * ─────────────────────────────────────────────────────────
 * Implements a weighted graph search to find the best
 * multi-leg public transport routes across Kingston, Jamaica.
 *
 * Algorithm: Modified Dijkstra weighted by:
 *   - fastest:          40% time + 30% fare + 30% transfers
 *   - cheapest:         20% time + 60% fare + 20% transfers
 *   - fewest_transfers: 20% time + 20% fare + 60% transfers
 */

import { prisma } from "../server";

export interface Stop {
  id:            string;
  name:          string;
  stop_type:     string;
  operator:      string;
  parish:        string;
  latitude:      number;
  longitude:     number;
  routes_served: string[];
  distance_meters?: number;
}

export interface JourneyLeg {
  stepNumber:     number;
  type:           "walk" | "bus" | "taxi" | "intercity_bus";
  instruction:    string;
  fromStop:       string;
  toStop:         string;
  routeNumber:    string;
  operator:       string;
  fareJmd:        number;
  durationMins:   number;
  walkingMins?:   number;
  routeColor:     string;
}

export interface JourneyOption {
  optionLabel:    string;   // "Option A", "Option B"
  legs:           JourneyLeg[];
  totalFareJmd:   number;
  durationMins:   number;
  transferCount:  number;
  score:          number;
  mapPolyline:    string;   // encoded polyline for map
  safetyRating:   "safe" | "caution" | "unknown";
}

type Preference = "fastest" | "cheapest" | "fewest_transfers";

const WEIGHTS: Record<Preference, { time: number; fare: number; transfers: number }> = {
  fastest:          { time: 0.40, fare: 0.30, transfers: 0.30 },
  cheapest:         { time: 0.20, fare: 0.60, transfers: 0.20 },
  fewest_transfers: { time: 0.20, fare: 0.20, transfers: 0.60 },
};

const TRANSPORT_COLORS: Record<string, string> = {
  bus:          "#0D7A7A",
  taxi:         "#C9A227",
  intercity_bus:"#1A3E5C",
  walk:         "#666666",
};

export async function planJourney(params: {
  originStops:  Stop[];
  destStops:    Stop[];
  originName:   string;
  destName:     string;
  preference:   Preference;
}): Promise<JourneyOption[]> {
  const { originStops, destStops, originName, destName, preference } = params;
  const weights = WEIGHTS[preference];

  // Load all active routes and fares from DB
  const [allRoutes, allFares] = await Promise.all([
    prisma.routes.findMany({ where: { is_active: true } }),
    prisma.fares.findMany({ where: { is_current: true } }),
  ]);

  // Load transit scraper data (enriched live fares)
  const scraperFares = await prisma.$queryRaw<any[]>`
    SELECT operator, route, origin, destination, amount_jmd
    FROM fares
    WHERE is_current = true
    ORDER BY operator, route
  `;

  const options: JourneyOption[] = [];

  // ── Strategy 1: Direct route (no transfers) ───────────────────
  const directOption = await buildDirectOption(
    originStops, destStops, originName, destName,
    allRoutes, scraperFares, weights
  );
  if (directOption) options.push(directOption);

  // ── Strategy 2: One transfer via major hubs ───────────────────
  const transferHubs = ["Half Way Tree Transport Centre", "Downtown Kingston Terminal", "Cross Roads"];
  for (const hub of transferHubs) {
    const hubOption = await buildTransferOption(
      originStops, destStops, originName, destName,
      hub, allRoutes, scraperFares, weights
    );
    if (hubOption) options.push(hubOption);
  }

  // ── Sort by composite score ───────────────────────────────────
  options.sort((a, b) => a.score - b.score);

  // Label and return top 3
  return options.slice(0, 3).map((opt, i) => ({
    ...opt,
    optionLabel: ["Option A", "Option B", "Option C"][i],
  }));
}

async function buildDirectOption(
  originStops: Stop[], destStops: Stop[], originName: string, destName: string,
  routes: any[], fares: any[], weights: any
): Promise<JourneyOption | null> {
  // Find routes that connect origin area to destination area
  const originRouteNums = new Set(originStops.flatMap(s => parseRoutesServed(s.routes_served)));
  const destRouteNums   = new Set(destStops.flatMap(s => parseRoutesServed(s.routes_served)));

  const sharedRoutes = routes.filter(r =>
    r.route_number &&
    originRouteNums.has(r.route_number) &&
    destRouteNums.has(r.route_number)
  );

  if (!sharedRoutes.length) return null;

  const route = sharedRoutes[0];
  const fare  = lookupFare(fares, route.operator, originName, destName)
             || getFallbackFare(route.transport_type);

  const walkToStop  = estimateWalkTime(originStops[0]?.distance_meters || 300);
  const rideDuration = estimateRideDuration(route.origin, route.destination);

  const legs: JourneyLeg[] = [
    {
      stepNumber:   1,
      type:         "walk",
      instruction:  `Walk to ${originStops[0]?.name || "nearest stop"} (${walkToStop} min)`,
      fromStop:     originName,
      toStop:       originStops[0]?.name || "Stop",
      routeNumber:  "",
      operator:     "",
      fareJmd:      0,
      durationMins: walkToStop,
      walkingMins:  walkToStop,
      routeColor:   TRANSPORT_COLORS.walk,
    },
    {
      stepNumber:   2,
      type:         route.transport_type as any,
      instruction:  `Take ${route.operator} ${route.transport_type === "bus" ? "bus" : "taxi"} ${route.route_number} towards ${route.destination}`,
      fromStop:     originStops[0]?.name || route.origin,
      toStop:       destStops[0]?.name   || route.destination,
      routeNumber:  route.route_number,
      operator:     route.operator,
      fareJmd:      fare,
      durationMins: rideDuration,
      routeColor:   TRANSPORT_COLORS[route.transport_type] || TRANSPORT_COLORS.bus,
    },
    {
      stepNumber:   3,
      type:         "walk",
      instruction:  `Walk to ${destName}`,
      fromStop:     destStops[0]?.name || "Stop",
      toStop:       destName,
      routeNumber:  "",
      operator:     "",
      fareJmd:      0,
      durationMins: estimateWalkTime(destStops[0]?.distance_meters || 300),
      walkingMins:  estimateWalkTime(destStops[0]?.distance_meters || 300),
      routeColor:   TRANSPORT_COLORS.walk,
    },
  ];

  const totalFare    = legs.reduce((s, l) => s + (l.fareJmd || 0), 0);
  const totalTime    = legs.reduce((s, l) => s + l.durationMins, 0);
  const transfers    = 0;
  const score        = calcScore(totalTime, totalFare, transfers, weights);

  return {
    optionLabel:   "Option A",
    legs,
    totalFareJmd:  totalFare,
    durationMins:  totalTime,
    transferCount: transfers,
    score,
    mapPolyline:   "",
    safetyRating:  "safe",
  };
}

async function buildTransferOption(
  originStops: Stop[], destStops: Stop[], originName: string, destName: string,
  hubName: string, routes: any[], fares: any[], weights: any
): Promise<JourneyOption | null> {
  // Look up the hub stop
  const hub = await prisma.stops.findFirst({ where: { name: hubName, is_active: true } });
  if (!hub) return null;

  const hubRouteNums    = parseRoutesServed(hub.routes_served as any);
  const originRouteNums = new Set(originStops.flatMap(s => parseRoutesServed(s.routes_served)));
  const destRouteNums   = new Set(destStops.flatMap(s => parseRoutesServed(s.routes_served)));

  const leg1Routes = routes.filter(r =>
    r.route_number && originRouteNums.has(r.route_number) && hubRouteNums.includes(r.route_number)
  );
  const leg2Routes = routes.filter(r =>
    r.route_number && hubRouteNums.includes(r.route_number) && destRouteNums.has(r.route_number)
  );

  if (!leg1Routes.length || !leg2Routes.length) return null;

  const r1 = leg1Routes[0];
  const r2 = leg2Routes[0];

  // Avoid duplicate single-route option
  if (r1.route_number === r2.route_number) return null;

  const fare1 = lookupFare(fares, r1.operator, originName, hubName) || getFallbackFare(r1.transport_type);
  const fare2 = lookupFare(fares, r2.operator, hubName, destName)    || getFallbackFare(r2.transport_type);
  const walk1 = estimateWalkTime(originStops[0]?.distance_meters || 300);
  const walk2 = estimateWalkTime(destStops[0]?.distance_meters || 300);

  const legs: JourneyLeg[] = [
    {
      stepNumber: 1, type: "walk",
      instruction: `Walk to ${originStops[0]?.name || "nearest stop"} (${walk1} min)`,
      fromStop: originName, toStop: originStops[0]?.name || "Stop",
      routeNumber: "", operator: "", fareJmd: 0, durationMins: walk1, walkingMins: walk1,
      routeColor: TRANSPORT_COLORS.walk,
    },
    {
      stepNumber: 2, type: r1.transport_type as any,
      instruction: `Take ${r1.operator} route ${r1.route_number} to ${hubName}`,
      fromStop: originStops[0]?.name || r1.origin, toStop: hubName,
      routeNumber: r1.route_number, operator: r1.operator, fareJmd: fare1,
      durationMins: estimateRideDuration(r1.origin, hubName),
      routeColor: TRANSPORT_COLORS[r1.transport_type] || TRANSPORT_COLORS.bus,
    },
    {
      stepNumber: 3, type: "walk",
      instruction: `Transfer at ${hubName} — board ${r2.operator} route ${r2.route_number}`,
      fromStop: hubName, toStop: hubName,
      routeNumber: "", operator: "", fareJmd: 0, durationMins: 5, walkingMins: 5,
      routeColor: TRANSPORT_COLORS.walk,
    },
    {
      stepNumber: 4, type: r2.transport_type as any,
      instruction: `Take ${r2.operator} route ${r2.route_number} to ${destStops[0]?.name || destName}`,
      fromStop: hubName, toStop: destStops[0]?.name || destName,
      routeNumber: r2.route_number, operator: r2.operator, fareJmd: fare2,
      durationMins: estimateRideDuration(hubName, r2.destination),
      routeColor: TRANSPORT_COLORS[r2.transport_type] || TRANSPORT_COLORS.bus,
    },
    {
      stepNumber: 5, type: "walk",
      instruction: `Walk to ${destName}`,
      fromStop: destStops[0]?.name || "Stop", toStop: destName,
      routeNumber: "", operator: "", fareJmd: 0, durationMins: walk2, walkingMins: walk2,
      routeColor: TRANSPORT_COLORS.walk,
    },
  ];

  const totalFare = legs.reduce((s, l) => s + (l.fareJmd || 0), 0);
  const totalTime = legs.reduce((s, l) => s + l.durationMins, 0);
  const transfers = 1;
  const score     = calcScore(totalTime, totalFare, transfers, weights);

  return {
    optionLabel: "Option B",
    legs,
    totalFareJmd:  totalFare,
    durationMins:  totalTime,
    transferCount: transfers,
    score,
    mapPolyline:   "",
    safetyRating:  "safe",
  };
}

// ── Helpers ─────────────────────────────────────────────────────────

function parseRoutesServed(routes: any): string[] {
  if (!routes) return [];
  if (Array.isArray(routes)) return routes;
  try { return JSON.parse(routes as string); } catch { return []; }
}

function lookupFare(fares: any[], operator: string, origin: string, destination: string): number | null {
  const match = fares.find(f =>
    f.operator?.toLowerCase().includes(operator.toLowerCase()) && (
      (f.origin?.toLowerCase().includes(origin.toLowerCase().substring(0, 10)) &&
       f.destination?.toLowerCase().includes(destination.toLowerCase().substring(0, 10))) ||
      !f.origin  // flat fare for all routes
    )
  );
  return match ? parseFloat(match.amount_jmd) : null;
}

function getFallbackFare(transportType: string): number {
  const defaults: Record<string, number> = {
    bus:          100,
    taxi:         200,
    intercity_bus: 3900,
  };
  return defaults[transportType] || 150;
}

function estimateWalkTime(meters: number): number {
  return Math.max(2, Math.round(meters / 80)); // ~80 meters/min walking
}

function estimateRideDuration(from: string, to: string): number {
  // Known approximate durations in minutes between major Kingston stops
  const knownDurations: Record<string, number> = {
    "half way tree_downtown kingston": 25,
    "downtown kingston_half way tree": 30,
    "papine_downtown kingston":        35,
    "downtown kingston_papine":        40,
    "portmore_downtown kingston":      45,
    "downtown kingston_portmore":      50,
    "spanish town_downtown kingston":  60,
    "half way tree_papine":            20,
    "cross roads_half way tree":       10,
    "cross roads_downtown kingston":   15,
    "half way tree_constant spring":   20,
    "kingston_montego bay":            270,
    "kingston_ocho rios":              90,
    "kingston_mandeville":             90,
  };

  const key = `${from.toLowerCase()}_${to.toLowerCase()}`;
  return knownDurations[key] || 20; // default 20 min
}

function calcScore(timeMins: number, fareJmd: number, transfers: number, weights: any): number {
  // Normalize each dimension to 0-100 scale then weight
  const timeScore     = Math.min(timeMins / 120, 1) * 100;
  const fareScore     = Math.min(fareJmd / 1000, 1) * 100;
  const transferScore = Math.min(transfers / 3, 1)  * 100;

  return (timeScore     * weights.time)
       + (fareScore     * weights.fare)
       + (transferScore * weights.transfers);
}
