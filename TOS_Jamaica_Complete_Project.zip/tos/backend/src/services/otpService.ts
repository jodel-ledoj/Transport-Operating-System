// ── OTP Service ───────────────────────────────────────────────────────────────
import crypto from "crypto";
import bcrypt from "bcryptjs";

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export async function hashOTP(otp: string): Promise<string> {
  return bcrypt.hash(otp, 10);
}

export async function sendOTPViaSMS(phone: string, otp: string): Promise<void> {
  if (process.env.NODE_ENV !== "production" || !process.env.TWILIO_ACCOUNT_SID) {
    // In dev mode, log the OTP to console (no actual SMS)
    console.log(`\n📱 [DEV OTP] Phone: ${phone} — Code: ${otp}\n`);
    return;
  }

  const twilio = require("twilio");
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

  await client.messages.create({
    body: `Your TOS Jamaica verification code is: ${otp}. Valid for 10 minutes.`,
    from: process.env.TWILIO_PHONE,
    to:   phone,
  });
}
