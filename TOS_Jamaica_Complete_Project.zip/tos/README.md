# 🇯🇲 TOS — Transport Operating System Jamaica

> Jamaica's public transport intelligence platform.
> Find JUTC bus routes, route taxi fares, and multi-leg journeys across Kingston — with safety alerts and live scraped data.

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Nginx (Port 80)                   │
│              Reverse Proxy + Rate Limiting           │
└──────────┬──────────────┬──────────────┬────────────┘
           │              │              │
   ┌───────▼──────┐ ┌─────▼─────┐ ┌────▼───────────┐
   │   Frontend   │ │  Backend  │ │    Scraper     │
   │  Next.js 14  │ │  Fastify  │ │  Python 3.12   │
   │   Port 3000  │ │  Port 4000│ │  Port 8001     │
   └──────────────┘ └─────┬─────┘ └────┬───────────┘
                          │             │
               ┌──────────▼─────────────▼──────────┐
               │        PostgreSQL 15 + PostGIS     │
               │   Routes • Stops • Fares • Users   │
               └──────────┬────────────────────────┘
                          │
               ┌──────────▼──────────┐
               │     Redis 7         │
               │  Sessions • Cache   │
               └─────────────────────┘
```

## Services

| Service   | Tech                   | Purpose                                   |
|-----------|------------------------|-------------------------------------------|
| Frontend  | Next.js 14 + Tailwind  | Web app — route planner, safety map       |
| Backend   | Node.js + Fastify      | REST API, route engine, auth              |
| Scraper   | Python 3.12 + FastAPI  | Weekly JUTC/OUR/Knutsford data scraping   |
| Database  | PostgreSQL + PostGIS   | All data storage + spatial queries        |
| Cache     | Redis                  | OTP codes, sessions, route graph cache    |
| Proxy     | Nginx                  | Routing, rate limiting, HTTPS             |

---

## Quick Start

### 1. Clone and configure
```bash
git clone https://github.com/your-org/tos-jamaica.git
cd tos-jamaica

# Configure environment
cp .env.example .env
# Edit .env: set JWT_SECRET, MAPBOX_TOKEN, and optionally TWILIO credentials
```

### 2. Start everything
```bash
docker-compose up --build
```

This will:
- Start PostgreSQL with PostGIS and run the init.sql seed data
- Start Redis
- Build and start the backend API (port 4000)
- Build and start the Python scraper (runs initial scrape on first boot)
- Build and start the Next.js frontend (port 3000)
- Start Nginx proxy (port 80)

### 3. Open the app
```
http://localhost          # Main app (via Nginx)
http://localhost:3000     # Frontend direct
http://localhost:4000     # Backend API
http://localhost:4000/health  # Health check
```

---

## Scraper Integration

The scraper runs automatically. No manual steps needed.

**Weekly schedule:** Every Sunday at 2:00 AM Jamaica time.

**Sources scraped:**
- JUTC (jutc.com.jm) — bus routes, stops, fares
- OUR (our.org.jm) — regulated route taxi fares
- Knutsford Express (knutsfordexpress.com) — intercity schedules & fares

**Manual trigger (admin panel):**
```
POST /api/transit/scrape
```
Or visit the Admin Dashboard and click "Run Scrape".

**Check scraper status:**
```
GET /api/transit/status
```

**Fallback:** All scrapers include hardcoded last-verified data.
If a website blocks scraping or goes offline, the app continues using cached/seeded data.

---

## API Endpoints

### Auth
| Method | Path                | Description              |
|--------|---------------------|--------------------------|
| POST   | /api/auth/register  | Send OTP to phone        |
| POST   | /api/auth/verify-otp| Verify OTP, get JWT      |
| GET    | /api/auth/me        | Get current user profile |
| POST   | /api/auth/logout    | Invalidate session       |

### Journey Planning
| Method | Path                | Description              |
|--------|---------------------|--------------------------|
| POST   | /api/journey/plan   | Plan a journey (core)    |
| GET    | /api/journey/history| User journey history     |
| PATCH  | /api/journey/:id/complete | Mark journey done |

### Transport Data (Live from Scraper)
| Method | Path                    | Description              |
|--------|-------------------------|--------------------------|
| GET    | /api/transit/routes     | All routes               |
| GET    | /api/transit/fares      | All current fares        |
| GET    | /api/transit/stops      | All stops & terminals    |
| GET    | /api/transit/schedules  | Intercity schedules      |
| GET    | /api/transit/fare-lookup| Cheapest fare A→B        |
| GET    | /api/transit/status     | Last scrape run report   |
| POST   | /api/transit/scrape     | Trigger manual scrape    |

### Safety
| Method | Path              | Description              |
|--------|-------------------|--------------------------|
| GET    | /api/safety/zones | All safety zones         |
| GET    | /api/safety/check?lat=&lng= | Check coordinates |

---

## Development

### Backend only
```bash
cd backend
npm install
npm run dev
```

### Frontend only
```bash
cd frontend
npm install
npm run dev
```

### Scraper only
```bash
cd scraper
pip install -r requirements.txt
cp .env.example .env  # set TRANSIT_DB_URL
python -m scheduler.orchestrator --run-now
```

---

## Adding New Scrapers

1. Create `scraper/scrapers/my_source_scraper.py`
2. Inherit from `BaseScraper`, implement `source_name`, `data_type`, `scrape()`
3. Add to `SCRAPERS` list in `scraper/scheduler/orchestrator.py`

The scheduling, change detection, and DB storage are automatic.

---

## Environment Variables

| Variable              | Required | Description                            |
|-----------------------|----------|----------------------------------------|
| DATABASE_URL          | ✅       | PostgreSQL connection string           |
| JWT_SECRET            | ✅       | 32+ char secret for signing tokens     |
| MAPBOX_TOKEN          | ✅       | Mapbox GL JS access token              |
| TWILIO_ACCOUNT_SID    | Optional | SMS OTP (dev uses console logging)     |
| TWILIO_AUTH_TOKEN     | Optional | Twilio auth token                      |
| TWILIO_PHONE          | Optional | Twilio phone number                    |
| TRANSIT_DB_URL        | ✅       | Same as DATABASE_URL (for scraper)     |

---

## Tech Stack

| Layer     | Technology                    |
|-----------|-------------------------------|
| Frontend  | Next.js 14, React 18, Tailwind CSS |
| Backend   | Node.js, Fastify, Prisma ORM  |
| Database  | PostgreSQL 15 + PostGIS 3.4   |
| Cache     | Redis 7                       |
| Scraper   | Python 3.12, httpx, BeautifulSoup, APScheduler |
| Maps      | Mapbox GL JS                  |
| Auth      | JWT (RS256), OTP via Twilio   |
| Container | Docker + Docker Compose       |
| Proxy     | Nginx                         |

---

*Built for the Kingston Hackathon. Transport Operating System — Jamaica. 2025.*
