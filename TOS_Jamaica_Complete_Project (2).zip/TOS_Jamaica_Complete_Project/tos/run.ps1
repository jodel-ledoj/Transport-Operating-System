$ErrorActionPreference = "Continue"
Set-Location "c:/Users/NETMERGE/Downloads/TOS_Jamaica_Complete_Project/tos"

Write-Host "Starting Docker Compose..."
docker compose up --build

Write-Host "Docker Compose finished. Checking containers..."
docker ps -a

